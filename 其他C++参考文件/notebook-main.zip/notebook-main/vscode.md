# vscode使用教程

## 目录



- [快捷键](https://blog.csdn.net/qq_45261963/article/details/108695261?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522165396706116782391845848%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=165396706116782391845848&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_click~default-2-108695261-null-null.142^v11^pc_search_result_control_group,157^v12^new_style2&utm_term=vscode%E5%BF%AB%E6%8D%B7%E9%94%AE&spm=1018.2226.3001.4449)
- [vscode刷leetcode](https://blog.csdn.net/ambition_zhou/article/details/115064786?ops_request_misc=&request_id=&biz_id=102&utm_term=%E9%85%8D%E7%BD%AEvscode%E7%9A%84%E5%8A%9B%E6%89%A3%E6%8F%92%E4%BB%B6&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduweb~default-1-115064786.142^v11^pc_search_result_control_group,157^v12^new_style2&spm=1018.2226.3001.4449)
- [远程开发](https://blog.csdn.net/qq_38120851/article/details/107696066?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522165396730616782248534915%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=165396730616782248534915&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~top_click~default-2-107696066-null-null.142^v11^pc_search_result_control_group,157^v12^new_style2&utm_term=vscode%E8%BF%9C%E7%A8%8B%E8%BF%9E%E6%8E%A5%E6%9C%8D%E5%8A%A1%E5%99%A8&spm=1018.2226.3001.4449)

