# 树形dp

## 目录

- [DP54](#DP54)
- [DP55](#DP55)
- [DP56](#DP56)
- [DP57](#DP57)
- [DP58](#DP58)


### DP54
* DP54 小红的树

描述
```
小红拿到了一棵有根树。根节点为1号节点。
所谓树，指没有回路的无向连通图。
现在小红想给一部分点染成红色。之后她有 q次询问，每次询问某点的子树红色节点的个数。
输入描述：
第一行一个正整数 n，代表树的节点个数。
第二行有 n-1个正整数，分别表示第 2个节点到第 n个节点每个节点的父亲。
接下来一个长度为 n的、由'W'或'R'字符组成的字符串。第 i个字符为'W'代表该字符没被染色，若字符为'R'代表该字符被染成了红色。
接下来一个正整数 q，代表小红的询问次数。
接下来的 q行，每行有一个正整数x，代表一次询问。
(1≤n,q≤10^5,1≤x≤n)
输出描述：
对于每次询问，输出一个整数，代表节点xx的子树的红色节点个数。
```
<!-- ![img]() -->
```cpp

```

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>


### DP55
* DP1 dosomething

描述
```

```
<!-- ![img]() -->
```cpp

```

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>


### DP56
* DP1 dosomething

描述
```

```
<!-- ![img]() -->
```cpp

```

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>


### DP57
* DP1 dosomething

描述
```

```
<!-- ![img]() -->
```cpp

```

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>


### DP58
* DP1 dosomething

描述
```

```
<!-- ![img]() -->
```cpp

```

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>

