# Learn English
[参考链接](https://blog.csdn.net/duduwolf/article/details/80546?ops_request_misc=&request_id=&biz_id=102&utm_term=%E6%9C%80%E5%B8%B8%E7%94%A8%E7%9A%84%E8%8B%B1%E8%AF%AD%E5%8D%95%E7%BA%AF&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduweb~default-3-80546.142^v59^new_blog_pos_by_title,201^v3^add_ask&spm=1018.2226.3001.4187)
# 目录
- [英语九百句](#英语九百句)
- [常用职位英文译名](#常用职位英文译名)
- [超级短句](#超级短句)
- [成语集锦](#成语集锦)
- [打开话匣子](#打开话匣子)
- [PC电脑词汇](#PC电脑词汇)
- [一百个绝佳句型](#一百个绝佳句型)
- [李阳英语365句](#李阳英语365句)
- [托福听力常用短语](#托福听力常用短语)
- [校园英语迷你惯用语](#校园英语迷你惯用语)
- [洋话连篇](#洋话连篇)
- [至理名言](#至理名言)



# 英语九百句


<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>
## Greetings 问候语

| hello!/hi! |      |
| ---------- | ---- |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |
|            |      |

## Expression In Class 课堂用语

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Identifying Objects 辨别物品

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Belongings 关于所有物

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Identifying People 辨别身份

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Introduction 关于介绍

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Year, Month And Day 年、月、日

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Objects 谈论事物

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Time 叙述时间

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Dates 关于日期

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Visits 关于拜访

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Language 关于语言

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Activities

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Age

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Daily Activities

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Yesterday

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking With Friends

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About The Past

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About The Address

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Asking Questions

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Measuring And Comparing

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Asking For Help

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Asking Directions

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Marriage

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Neighbors And Friends

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Planning The Future

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About The Weather

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Sickness

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Habits

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Asking For Other's Opinions

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Making Plans

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Decisions

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Traveling

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Shopping

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## In The Restaurant

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Evening Entertainment

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Appointments

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Seeing A Doctor

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Making A Phonecall

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Mail

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Feelings

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Looking For A House

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Dressing

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Expressing Different Opinions

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Things In The Future

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Things That Might Have Happened

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Talking About Likes And Dislikes

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Putting Forward Your Own Opinios

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Getting Ready For A Journey

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Countries And Nationalities

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Geography And Land Features

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## School And Education

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Jobs

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Farms And Factories

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Hobbies

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Recreational Activities

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Newspapers And Magazines

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## Radio And TV

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |

## About Music And Literature

|      |      |
| ---- | ---- |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |
|      |      |




# 常用职位英文译名


<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>

|      |      |
| ---- | ---- |
|Accounting Assistant |会计助理 |
|Accounting Clerk |记帐员 |
|Accounting Manager| 会计部经理 
|Accounting Stall |会计部职员 
|Accounting Supervisor |会计主管 
|Administration Manager |行政经理 
|Administration Staff |行政人员 
|Administrative Assistant |行政助理 
|Administrative Clerk |行政办事员 
|Advertising Staff |广告工作人员 
|Airlines Sales Representative |航空公司定座员 
|Airlines Staff |航空公司职员 
|Application Engineer |应用工程师 
|Assistant Manager |副经理 
|Bond Analyst |证券分析员 
|Bond Trader |证券交易员 
|Business Controller |业务主任 
|Business Manager |业务经理 
|Buyer |采购员 
|Cashier |出纳员 
|Chemical Engineer |化学工程师 
|Civil Engineer |土木工程师 
Clerk/Receptionist |职员/接待员 
Clerk Typist & Secretary |文书打字兼秘书 
Computer Data Input Operator |计算机资料输入员 
Computer Engineer |计算机工程师 
Computer Processing Operator |计算机处理操作员 
Computer System Manager |计算机系统部经理 
Copywriter |广告文字撰稿人 
Deputy General Manager |副总经理 
Economic Research Assistant |经济研究助理 
Electrical Engineer |电气工程师 
Engineering Technician |工程技术员 
English Instructor/Teacher |英语教师 
Export Sales Manager |外销部经理 
Export Sales Staff |外销部职员 
Financial Controller |财务主任 
Financial Reporter |财务报告人 
f.x. (foreign exchange)clerk |外汇部职员 
f.x. settlement clerk |外汇部核算员 
Fund Manager |财务经理 
General Auditor |审计长 
General Manager/ President |总经理 
General Manager Assistant |总经理助理 
General Manager's Secretary |总经理秘书 
Hardware Engineer |计算机硬件工程师 
Import Liaison Staff |进口联络员 
Import Manager |进口部经理 
Insurance Actuary |保险公司理赔员 
International Sales Staff |国际销售员 
Interpreter |口语翻译 
Legal Adviser |法律顾问 
Line Supervisor |生产线主管 
Maintenance Engineer |维修工程师 
Management Consultant |管理顾问 
Manager |经理 
Manager for Public Relations |公关部经理 
Manufacturing Engineer |制造工程师 
Manufacturing Worker |生产员工 
Market Analyst |市场分析员 
Market Development Manager |市场开发部经理 
Marketing Manager |市场销售部经理 
Marketing Staff |市场销售员 
Marketing Assistant |销售助理 
Marketing Executive |销售主管 
Marketing Representative |销售代表 
Marketing Representative Manager |市场调研部经理 
Mechanical Engineer |机械工程师 
Mining Engineer |采矿工程师 
Music Teacher |音乐教师 
Naval Architect |造船工程师 
Office Assistant |办公室助理 
Office Clerk |职员 
Operational Manager |业务经理 
Package Designer |包装设计师 
Passenger Reservation Staff |乘客票位预订员 
Personnel Clerk |人事部职员 
Personnel Manager |人事部经理 
Plant/ Factory Manager |厂长 
Postal Clerk |邮政人员 
Private Secretary |私人秘书 
Product Manager |生产部经理 
Production Engineer |产品工程师 
Professional Staff |专业人员 
Programmer |电脑程序设计师 
Project Staff |项目策划人员 
Promotional Manager |推售部经理 
Proof-reader |校对员 
Purchasing Agent |采购进货员 
Quality Control Engineer |质量管理工程师 
Real Estate Staff |房地产职员 
Recruitment Co-ordinator |招聘协调人 
Regional Manger |地区经理 
research＆.development engineer |研究开发工程师 
Restaurant Manager |饭店经理 
Sales and Planning Staff |销售计划员 
Sales Assistant |销售助理 
Sales Clerk 店员、|售货员 
Sales Coordinator |销售协调人 
Sales Engineer |销售工程师 
Sales Executive |销售主管 
Sales Manager |销售部经理 
Salesperson |销售员 
Seller Representative |销售代表 
Sales Supervisor |销售监管 
School Registrar |学校注册主任 
Secretarial Assistant |秘书助理 
Secretary |秘书 
Securities Custody Clerk| 保安人员 
Security Officer |安全人员 
Senior Accountant |高级会计 
Senior Consultant/Adviser |高级顾问 
Senior Employee |高级雇员 
Senior Secretary |高级秘书 
Service Manager |服务部经理 
Simultaneous Interpreter |同声传译员 
Software Engineer |计算机软件工程师 
Supervisor |监管员 
Systems Adviser |系统顾问 
Systems Engineer |系统工程师 
Systems Operator |系统操作员 
Technical Editor |技术编辑 
Technical Translator |技术翻译 
|Technical Worker |技术工人 
|Telecommunication Executive|电讯（电信）员 
|Telephonist / Operator |电话接线员、话务员 
|Tourist Guide |导游 
|Trade Finance Executive |贸易财务主管 
|Trainee Manager |培训部经理 
|Translation Checker |翻译核对员 
|Translator |翻译员 
|Trust Banking Executive |银行高级职员 
|Typist |打字员 
|Wordprocessor Operator |文字处理操作员 


# 超级短句

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>

|      |      | 
| ---- | ---- | 
1.absolutely not.  |绝对不是。
2.are you coming with me?  |你跟我一起去吗？ 
3.are you sure?  |你能肯定吗？ 
4.as soon as possible.  |尽快。 
5.believe me.  |相信我。 
6.buy it .  |买下来！ 
7.call me tomorrow.  |明天打电话给我。 
8.can you speak slowly?  |请您说得慢些好吗？ 
9.come with me.  |跟我来。 
10.congratulations.  |恭喜恭喜。 
11.do it right!  |把它做对。 
12.do you mean it ?  |你是当真的吗？ 
13.do you see him often? | 你经常见到他吗？ 
14.do you see it? = do you understand?  |你明白了吗？ 
15.do you want it?  |你要吗？ 
16.do you want something?  |你想要些什么？ 
17.don’t do it .  |不要做。 
18.don’t exaggerate.  |不要夸张。 
19.don’t tell me that.  |不要告诉我。 
20.give me a hand .  |帮我一下。 
21.go right ahead.  |一直往前走。 
22.have a good trip. | 祝旅途愉快。 
23.have a nice day.  |祝你一天过得愉快。 
24.have you finished?  |你做完了吗？ 
25.he doesn’t have time.  |他没空。 
26.he is on his way.  |他现在已经在路上了。 
27.how are you doing?　 |你好吗？ 
28.how long are you staying ?  |你要呆多久？ 
29.i am crazy about her.  |我对她着迷了。 
30.i am wasting my time .  |我在浪费时间。 
31.i can do it .  |我能做。 
32.i can’t believe it . |我简直不能相信。 
33.i can’t wait .  |我不能再等了。 
34.i don’t have time .  |我没时间了。 
35.i don’t know anybody.  |我一个人都不认识。 
36.i don’t like it .  |我不喜欢。 
37.i don’t think so .　 |我认为不是。 
38.i feel much better.  |我感觉好多了。 
39.i found it .　 |我找到了。 
40.i hope so .  |我希望如此。 
41.i knew it .　 |我早知道了。 
42.i noticed that.  |我注意到了。 
43.i see.  |我明白了。 
44.i speak english well. | 我英语说得很好。 
45.i think so .  |我认为是这样的。 
46.i want to speak with him.  |我想跟他说话。 
47.i won.  |我赢了。 
48.i would like a cup of coffee, please.  |请给我一杯咖啡。 
49.i’m hungry.  |我饿死了。 
50.i’m leaving.  |我要走了。 
51.i’m sorry.  |对不起。 
52.i’m used to it .  |我习惯了。 
53.i’ll miss you.  |我会想念你的。 
54.i’ll try.  |我试试看。 
55.i’m bored.  |我很无聊。 
56.i’m busy.  |我很忙。 
57.i’m having fun.  |我玩得很开心。 
58.i’m ready.  |我准备好了。 
59.i’ve got it .  |我明白了。 
60.i’ve had it .  |我受够了。 
61.it’s incredible!  |真是难以置信！ 
62.is it far?  |很远吗？ 
63.it doesn’t matter.  |没关系。 
64.it smells good.  |闻起来很香。 
65.it’s about time .  |是时候了。 
66.it’s all right.  |没关系。 
67.it’s easy.  |很容易。 
68.it’s good.  |很好。 
69.it’s near here.  |离这很近。 
70.it’s nothing. | 没什么。 
71.it’s time to go .  |该走了。 
72.it’s different.  |那是不同的。 
73.it’s funny.  |很滑稽。 
74.it’s impossible.  |那是不可能的。 
75.it’s not bad.  |还行。 
76.it’s not difficult.  |不难. 
77.it’s not worth it .　 |不值得。 
78.it’s obvious.  |很明显。 
79.it’s the same thing.  |还是一样的。 
80.it’s your turn.  |轮到你了。 
81.let me see .  |让我想想。 
82.let me know .  |告诉我。 
83.me too.  |我也一样。 
84.not yet.  |还没有。 
85.relax!  |放松。 
86.see you tomorrow.　 |明天见。 
87.she is my best friend .  |她是我最好的朋友。 
88.she is so smart.  |她真聪明。 
89.show me .　 |指给我看。 
90.tell me .  |告诉我。 
91.thank you very much.　 |多谢。 
92.that happens. | 这样的事情经常发生。 
93.that’s enough.  |够了。 
94.that’s interesting. | 很有趣。 
95.that’s right.  |对了。 
96.that’s true.  |这是真的。 
97.there are too many people here.  |这里人很多。 
98.they like each other.  |他们互相倾慕。 
99.think about it .  |考虑一下。 
100.too bad! | 太糟糕啦！ 
101.wait for me .  |等等我。 
102.what did you say?  |你说什么？ 
103.what do you think?  |你认为怎样？ 
104.what is he talking about?  |他在说些什么？ 
105.what terrible weather!  |多坏的天气。 
106.what’s going on/ happening / the problem?  |怎么啦？ 
107.what’s the date today? |今天几号？ 
108.where are you going ?  |你去哪里？ 
109.where is he?  |他在哪里？ 
110.you are impatient.  |你太性急了。 
111.you look tired.  |你看上去很累。 
112.you surprise me.  |你让我大吃一惊。 
113.you’re crazy. | 你疯了。 
114.you’re welcome.  |别客气。 
115.you’re always right.  |你总是对的。 
116.you’re in a bad mood.  |你的心情不好。 
117.you’re lying.  |你在撒谎。 
118.you’re wrong.  |你错了。
|      |      |      |





# 成语集锦


<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>


> 1.world is but a little place, after all. 
> 天涯原咫尺，到处可逢君 
>
> Explanation: it is used when a person meets someone he knows or is in someway connected 
> with him in a place where he would never have expected to do so. 
>
> example: who would have thought i would bump into an old schoolmate on a trek up mount tai.
>  the world is but a little place after all. 
>
> 2. when in rome, do as the romans do. 
> 入乡随俗 
>
> explanation: conform to the manners and customs of those amongst whom you live. 
>
> Example: I know you have egg and bacon for breakfast at home, but now you are on the Continent
>  you will do as the romans do and take coffee and rolls. 
>
> 3. what you lose on the swings you get back on the roundabouts. 
> 失之东隅，收之桑榆 
>
> Explanation: a rough way of starting a law of average; if you have bad luck on one day you have
>  good on another; if one venture results in loss try a fresh one---it may succeed. 
>
> Example: he may always possess merits which make up for everything; if he loses on the swings, 
> he may win on the roundabouts. 
>
> 4.what are the odds so long as you are happy. 
> 知足者常乐 
>
> explanation: what does anything else matter if a person is happy. 
>
> example: you complain so much, but you have a good family, parents, health, and money. 
> what’s the odd so long as you’re happy. 
>
> 5．entertain an angel unawares. 
> 有眼不识泰山 
>
> explanation: to receive a great personage as a guest without knowing his merits. 
>
> Example: in the course of evening someone informed her that she was entertaining an angel 
> unawares, in the shape of a composer of the greatest promise 
>
> 6.every dog has his day . 
> 是人皆有出头日 
>
> Explanation: fortune comes to each in turn 
>
> example: they say that every dog has his day; but mine seems a very long time coming. 
>
> 7.every potter praises his own pot. 
> 王婆买瓜，自卖自夸 
>
> Explanation: people are loath to refer to defects in their possessions or their family members 
>
> Example: he said that his teacher considered his work brilliant, but I would rather hear it from his 
> teacher’s own mouth. every potter praises his own pot 
>
> ------------------------------------------------------------------------------------
>
> We are good friends! 
>
> 
>
> 　 1． pain past is pleasure. 
> （过去的痛苦就是快乐。）[无论多么艰难一定要咬牙冲过去，将来回忆起来一定甜蜜无比。] 
> 2． while there is life, there is hope. 
> （有生命就有希望/留得青山在，不怕没柴烧。） 
>
> 3． wisdom in the mind is better than money in the hand. 
> （脑中有知识，胜过手中有金钱。）[从小灌输给孩子的坚定信念。] 
> 4． storms make trees take deeper roots. 
> （风暴使树木深深扎根。）[感激敌人，感激挫折！] 
> 5． nothing is impossible for a willing heart. 
> （心之所愿，无所不成。）[坚持一个简单的信念就一定会成功。] 
> 6． the shortest answer is doing. 
> （最简单的回答就是干。）[想说流利的英语吗？那么现在就开口！心动不如嘴动。] 
> 7． all things are difficult before they are easy. 
> （凡事必先难后易。）[放弃投机取巧的幻想。] 
>
> 8． great hopes make great man. （伟大的理想造就伟大的人。） 
> 9． god helps those who help themselves.（天助自助者。） 
> 10． four short words sum up what has lifted most successful individuals above the crowd: a little bit more. 
>    （四个简短的词汇概括了成功的秘诀：多一点点！） 
>    [比别人多一点努力、多一点自律、多一点决心、多一点反省、多一点学习、多一点实践、多一点疯狂，多一点点就能创造奇迹！] 
> 11． in doing we learn.（实践长才干。） 
> 12． east or west, home is best.（东好西好，还是家里最好。） 
> 13． two heads are better than one.（三个臭皮匠，顶个诸葛亮。） 
> 14． good company on the road is the shortest cut.（行路有良伴就是捷径。） 
> 15． constant dropping wears the stone.（滴水穿石。） 
> 16． misfortunes never come alone/single.（祸不单行。） 
> 17． misfortunes tell us what fortune is.（不经灾祸不知福。） 
> 18． better late than never.（迟做总比不做好；晚来总比不来好。） 
> 19． it's never too late to mend.（过而能改，善莫大焉；亡羊补牢，犹未晚也。） 
> 20． if a thing is worth doing it is worth doing well.（如果事情值得做，就值得做好。） 
> 21． nothing great was ever achieved without enthusiasm.（无热情成就不了伟业。） 
> 22． actions speak louder than words.（行动比语言更响亮。） 
> 23． lifeless, faultless.（只有死人才不犯错误。） 
> 24． from small beginning come great things.（伟大始于渺小。） 
> 25． one today is worth two tomorrows.（一个今天胜似两个明天。） 
> 26． truth never fears investigation.（事实从来不怕调查。） 
> 27． the tongue is boneless but it breaks bones.（舌无骨却能折断骨。） 
> 28． a bold attempt is half success.（勇敢的尝试是成功的一半。） 
> 29． knowing something of everything and everything of something. 
>      （通百艺而专一长。）[疯狂咬舌头] 
> 30． good advice is beyond all price.（忠告是无价宝。）


# 打开话匣子


<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>



# PC电脑词汇


<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>
|      |      |
| ---- | ---- |
|      |      |
|      |      |
abbreviate |vt.缩写，省略 
abbreviation |n.缩短，省略，简称 
abend 异常结束 
abnormal 异常 
abort 异常中止 
aboveboard ad.照直，公开的 
absence n.缺少，没有 
absolute 绝对 
absorption 吸收 
abstract 抽象 
acceleration 加速度 
accelerator n.加速装置，加速剂 
accent 强调 
accept 接受 
accepting 接收 
access 访问 
accessible 可存取 
accessor 存取元 
accessory 附件 
accidentally ad.偶然地 
accommodate 容纳 
according to a.按照，根据 
account 帐户 
accounting 会计 
accumulate 累加 
accumulator 累加器 
accuracy 准确度 
accurately 准确地 
achieve vt.完成 
ACK 确认符 
acknowledge 确认 
acknowledgement 确认 
acknowledgment n.接收(收妥)，承认 
acoustic 声音的 
acquire 获取 
acquisition 获取 
acronym 字首组合词 
across 跨越 
action 动作 
activate 激活 
activation 激活 
active 活动的 
activity 活动 
actual 实际的 
actuator 致动器 
adaptability 适应性 
adapter 适配器 
add 添加 
addend 加数 
adder 加法器 
addition n.加法，增加 
additional 附加的 
additionally ad.另外，又 
additive 添加的 
address 地址 
addressability 可寻址性 
addressee 被访地址 
addressing 寻址 
adequate a.足够的，充分的 
adjacency 邻近 
adjacent 邻近的 
adjust 调整 
adjustment 调整 
administration 管理 
administrative 管理的 
administrator 管理员 
advance v.进展 
advanced 高级的 
affect vt.影响，改变，感动 
affected a.受了影响的 
again 再次 
aggregate 聚集 
aid n.帮助，辅助程序 
airflow 气流 
aisle 通道 
alarm 警报 
alert 报警 
algebraic 代数 
algorithm 算法 
alias 别名 
aliasing 别名判别 
align v.定位，对齐 
aligned a. 对齐的，均衡的 
aligner 调整器 
alignment 数据对齐 
all 全部 
allocate 分配 
allocation 分配 
allocator 分配器 
allow 允许 
allowable a.容许的，承认的 
allowance 允许 
allowed a.容许的 
ally v.联合，与...关联 
alpha n.希腊字母α，未知数 
alphabet 字母 
alphabetic 字母的 
alphabetical a.字母(表)的，abc的 
alphabetically ad.按字母表顺序 
alphameric 字母数字的 
alphanumeric 字母数字的 
alter 改变 
alteration 改动 
alternate 替代 
alternately ad.交替地，轮流地 
alternative 替代项 
amber 琥珀色 
amount 金额 
amp 安培 
ampere 安培 
ampersand n.＆号(and) 
amplifier 放大器 
amplitude 振幅 
analog 模拟 
analogue 模拟 
analysis 分析 
analyst 分析员 
analyze 分析 
analyzer 分析机 
ancestor 祖先 
AND 与 
angle 角度 
Angstrom 埃 
animate 动画绘制 
Animation 动画 
annotate 注释 
annotation 注释 
announce vt.发表，宣布 
announcement 宣布 
announciator 报警器 
anode 阳极 
another 另一个 
ansi n.美国国家标准协会 
answering 应答 
antialiasing 排斥假名 
anticipate vt.预先考虑，抢...先 
antistatic 防静电 
aperture 小孔 
apostrophe 单引号 
appear 出现 
append 附加 
appendix n.附录 
apple n.苹果公司 
applicable a.可适用的，合适的 
application 应用（程序） 
applied a.适用的，外加的 
apply 应用 
appropriate 适当的 
appropriately ad.适当地 
apron 附表 
architecture 体系结构 
archive 归档 
area 区 
argument 参数 
arithmetic 算术 
arrange 排列 
arrangement 排列 
array 数组 
arrow 箭头 
article 物件 
ascend 上升 
ascending 升序 
ascii n.美国信息交换标准码 
assemble 汇编 
assembled 组装 
assembler 汇编程序 
assembly 汇编 
assertion 断言 
asset 资产 
Assign 分配 
assigned a.指定的，赋值的 
assignment 赋值 
assist 辅助 
assistance 辅助 
associate v.相联，联想，关联 
associated 关联的 
association 关联 
associativity 关联性 
assortment n.种类，花色品种 
assume 假设 
assumed a.假定的 
asterisk 星号 
async 异步 
asynchronous 异步 
atom 原子 
atomicity 原子性 
attach 连接 
attached a.附加的 
attachment 连接附件 
attempt 试图 
attention n.注意(信号) 
attenuation 衰减 
attenuator 衰减器 
attractive 吸引人的 
attribute 属性 
audio 声频 
audit 审查 
augend 被加数 
augment v.增加，添加，扩充 
authentication 认证 
authenticator 认证器 
author n.程序设计者，作者 
authority 权限 
authorization 权限 
authorize 授权 
authorized 特许的 
auto a.自动的 
autodialer 自动拔号器 
autoindex n.自动变址(数) 
automata 自动机 
automatic 自动的 
automatically ad.自动地，机械地 
automation 自动化 
automaton 自动机 
autonumber 自动号 
autopush 自动推 
autostart 自动启动 
auxiliary 辅助的 
availability 可用性 
available 可用的 
average 平均 
avoid vt.避免，取消，无效 
babble 串音 
backbone 主干 
backend 后端 
backflush 逆算法 
background 后台 
backlog 待办事项 
backscrolling 反卷 
backslash 反斜线 
backspace 退格 
backtab 退格制表 
backup 备份 
backward 反向 
badge 标记 
balance 平衡 
band 区 
bandwidth 带宽 
bank 存储单元 
banking 出界 
bar 条 
base 基数 
baseband 基带 
baseline 基线 
basename 基名 
basic 基本 
basis 基础 
bass 低音部 
batch 批处理 
battery 电池 
baud 波特 
beacon 信标 
beam 束 
beep n.蜂鸣声，嘀嘀声 
beeper 蜂鸣器 
begin 开始 
behavior 行为 
bel 贝尔 
bell 响铃 
bellfast 快贝尔 
below 下面 
benchmark 基准 
beyond prep.超过，那边 
bias 偏离 
bibliography 书目 
bid 请求 
bidder 请求者 
bill 票据 
billing 开票 
binary 二进制 
bind 联接 
binder 联接器 
binding 联接 
bionics 仿生学 
bios n.基本输入/输出系统 
bipolar 双极性的 
biquinary 二五混合进制（的） 
bistable 双稳态的 
bit 位 
bitmap 位图 
blank 空格 
blanket 涂层 
blink 闪烁 
blinking 闪烁 
blip （缩微胶卷画面上的光点）标志 
blit 位块传送 
block 块 
blocking 分块 
blower 鼓风机 
board n.板，插件板 
body 主体 
boldface 黑体 
book 书籍 
bookmark 书签 
Boolean 布尔 
boot 引导 
Bootable 可引导 
bootstrap 自举 
border 边框 
borrow 借位 
bottleneck 瓶颈 
bottom 底部 
bounce 弹回 
bound 界限 
boundary 边界 
box 框 
bpi 位／英寸 
bps 位／秒 
brace 花括号 
braces 花括号 
bracket 方括号 
bracketed a.加括号的 
brackets 方括号 
branch 分支 
break 中断 
breakpoint 断点 
breve 短音符号 
bridge 网桥 
bridging 桥接 
bright 明亮 
brightness 亮度 
broadband 宽频带 
broadcast 广播 
browse 浏览 
Browser 浏览器 
bucket 存储桶 
buffer 缓冲区 
buffering 缓冲 
bug 错误 
build 构建 
bulb 灯泡 
bumper 保险杆 
burst 脉冲串 
bus 总线 
business 商业 
bussback 反馈 
busy 忙 
button 按钮 
buyer 采购人员 
buzzer 蜂鸣器 
bypass 旁路 
byte 字节 

cable 电缆 
cabling 布线 
cache 高速缓存 
caching 高速缓存 
CAD 计算机辅助设计 
cage 盒子 
calculate 计算 
calculation n.计算，统计，估计 
calculator 计算器 
calendar 日历 
calibrate 校准 
call 调用 
callback 回叫 
caller 调用程序 
calling 调用 
callout 调出 
camcorder 便携式摄像机 
cancel 取消 
candidate 候选 
cannot 不能 
canvas 画布 
capability 能力 
capable 有能力的 
capacitor 电容 
capacity 能力 
capital 大写 
capitalized a.大写的 
caption 图表说明 
capture 捕捉 
card 卡 
caret 插入记号 
carousel n.圆盘传送带 
carriage 托架 
carrier 载波 
carry 进位 
cartridge 盒式磁带 
cascade 级联 
case n.情况，场合 
cash n.现金 
cassette 盒式磁带 
cast 强制转型 
catalog 编目 
catalogue 编目 
catch 捕捉 
category 种类 
cation n.正离子，阳离子 
cause 原因 
caution 注意 
CD 光盘，激光唱片 
cedilla 变音符 
cell 单元 
Celsius 摄氏 
center 中心 
centering 向中对齐 
centerline 中线 
centimeter 厘米 
central 中央的 
centrex 中央交换机 
century n.世纪 
certain a.确实的，确定的 
certainty n.必然，确实 
certification 确证 
chain 链 
chained 链接 
chaining 链接 
chamber 箱 
change 更改 
channel 通道 
channelizing 沟道效应 
chapter 章 
char 字符 
character 字符 
characteristic 特性 
charge 费用 
charging 充电 
chart 图表 
chassis 机壳 
check 检查 
checker 检查器 
checkout 检出 
checkpoint 检查点 
child 儿子节点 
children 子女 
chip 芯片 
choice 选项 
choose v.挑选，选择，选定 
chord 弦 
chunk n.厚块，大部分 
ciphertext 密码文本 
circle n.圆，圈，循环，周期 
circuit 电路 
circular 循环 
circumflex 弯曲 
circumstance n.情况，环境，细节 
citation 引用 
city 城市 
clamp 夹 
class 类 
classify 分类 
clause 子句 
clear 清除 
clearinghouse 清除库 
clerk 职员 
click 单击 
client 客户 
clip 裁剪 
clipboard 裁剪板 
cliping 裁剪 
clipper n.剪刀 
clock 时钟 
clocking 定时 
clockwise 顺时针方向 
Close 关闭 
closed a.关闭的，闭迹 
closely a.精密地，仔细地 
cluster 群集 
coalesce 结合 
coating 涂层 
coax 同轴 
coaxial 同轴的 
code 代码 
coder 编码器 
codeset 代码集 
coding 编码 
coefficient 系数 
coexist 共存 
coexistence 共存 
coffret 传输接口 
collapse 崩溃 
collate 整理 
collation 整理 
collator 整理器 
collection 堆集 
collision 冲突 
colon 冒号 
colour 颜色 
column 列 
combination 组合 
combine 组合 
combobox n.组合框 
comma 逗号 
command 命令 
comment 注解 
commercial a.商业的，经济的 
commit 落实 
commitment 落实 
commodity 商品 
common 公共的 
communicate 通信 
communication n.通信 
compact 压缩 
compaction 压缩 
company 公司 
comparand 比较字 
comparator 比较器 
compare 比较 
comparison 比较 
compatibility 兼容性 
compatible 兼容的 
compilation 编译 
compile 编译 
compiler 编译器 
complement 补码 
complementer 反相器 
complete 完成 
completely ad.十分，完全，彻底 
completion 完成 
complex 复杂的 
complexities 复杂性 
complexity 复杂程度 
complicated v.使复杂化，使混乱 
component 部件 
components 部件 
compose 组成 
composing 组成 
composite 合成 
composition 组合 
compress 压缩 
compression 压缩 
compressor 压缩器 
comprise vt.包括，由...组成 
compute 计算 
computer 计算机 
computing 计算 
concatenate 并置 
concatenation 并置 
concentration 集中 
concentrator 集线器 
concept n.概念 
concordance 重要语汇索引 
concurrent 同时的 
condense 压缩 
condition 条件 
conditional 条件的 
conditioning 调节 
conductor 导线 
conduit 护线管 
confidential 机密 
configuration 配置 
configurator 配置程序 
configure 配置 
confirm 确认 
confirmation 确认 
conflict v.冲突，碰头 
conflicting 冲突 
conform vi.遵从，符合 
confuse vt.使混乱，干扰 
congestion 拥塞 
conjunction 与 
connect 连接 
connected 连接 
connection 连接 
connective 连接词 
connectivity 连通性 
connector 连接器 
consecutive 连续的 
consent 插座 
consequently ad.因此，从而 
consider 考虑 
consideration n.考虑，研究，讨论 
considered a.考虑过的，被尊重的 
consist vi.符合，包括 
consistency 一致性 
consistent 一致的 
console 控制台 
consolidate 合并 
const n.常数 
constant 常量 
constantly ad.不变地，经常地 
constraint 约束 
constructing 构造 
constructor 构造成员 
consult v.咨询，顾问 
consumable 消费品 
consume v.消耗，使用 
contact 联系 
contain 包含 
container 容器 
containment 包含 
content 内容 
contention 争用 
context 上下文 
contextual 上下文的 
contiguous 相连的 
continue 继续 
continued 接上页 
continuously ad.连续不断地 
contractor 承包方 
contrast 反差 
control 控制 
controllability 可控制性 
controlled a.受控制的，受操纵的 
controller 控制器 
convegence 收敛 
convenience n.方便，便利 
convenient a.方便的，便利的 
convention 约定 
conventional a.常规的，习惯的 
converg 收敛 
converged 收敛的 
conversation 对话 
conversational 会话式 
conversion 转换 
convert 转换 
converted 转换的 
converter 转换器 
coordinate 坐标 
coordinator 协调程序 
coprocessor 协处理器 
copy 复制 
copying 复制 
copyright n.版权 
cord n.绳子，电线 
core 核心 
coresidency 共存 
corner 角 
corona 电晕 
correct 正确 
correction n.校正，修正 
correctly 正确 
correlator 相关因子 
correspond vi.通信(联系) 
corresponding 相应的 
corrupt v.有毛病的 
corrupted 毁坏的 
cosine 余弦 
cost 成本 
costing 成本法 
Coulomb 库仑 
count 计数 
counter 计数器 
counterclockwise 反时针方向 
country 国家 
coupler 耦合器 
coupling 耦合 
courier 信使 
course n.过程，航向，课程 
cover 盖 
CPU 控制处理部件 
crank 曲柄 
crash 崩溃 
craze n.开裂 
create 建立 
creation n.创造，创作 
creator 建立者 
credentials 凭证 
credit 信用 
crew 组员 
criteria 标准 
criterion n.标准，判据，准则 
critical 临界的 
crop v.切，剪切 
cross 跨 
crossfoot 交叉结算 
crowding 拥挤 
cryogenics 低温学 
cryotron 低温管 
cryptographic 密码 
cryptography 密码术 
CUA 公共用户存取访问 
culling 挑选 
cumulative 累积的 
current 当前 
currently ad.目前，现在 
cursor 光标 
curtate 卡片部分 
cushion 缓冲器 
custom a.用户 
customation 定制 
customer 用户 
customize 定制 
cut 剪下 
cutoff 截止 
cutout 开口 
cybernetics 控制论 
cycle 循环 
cyclinder 柱面 
cyrill 西里尔 
daemon 守护程序 
daily a.每日的，日常的 
damage 损坏 
damping 阻尼 
dark 黑暗 
DASD 直接存取存储器 
data 数据 
database 数据库 
datagram 数据报 
date 日期 
datum 数据 
day 天 
db 分贝 
deactivate 释放 
deactivated 释放 
deactivation 释放 
deadlock 死锁 
deal v.处理，分配，交易 
dealer 经销商 
deallocate 释放 
dearly ad.极，非常，昂贵地 
death n.毁灭，消灭 
debit 借额 
deblock 解块 
deblocking 解块 
debug 调试 
debugger 调试器 
deca 十（词头） 
deci 十分之一（词头） 
decibel 分贝 
decide v.(使)判定，判断 
decimal 十进制 
decipher 译码 
decision 判定 
deck 叠 
declaration 说明 
declarative 说明的 
declarator 说明符 
declare 说明 
declared a.承认的，申报的 
decode 译码 
decoder 译码器 
decollate 分开 
decompression 还原 
deconcentration 分散 
deconcentrator 分线器 
decrease v.减少，降低，缩短 
decreasing 递减 
decrement 减 
decrypt 译码 
decurl 去卷曲 
dedicate 专用 
dedicated 专用的 
dedication 专用 
deduction 扣除 
default 缺省 
defect 缺陷 
defective a.故障的，有毛病的 
definable a.可定义的，可确定的 
define 定义 
definition 定义限定 
deflect 转向 
degrade v.降低，减少，递降 
degree 度 
delay 延迟 
deleave 拆散 
delegation 授权 
delete 删除 
deletion n.删去(部分)，删除 
delimit 定界 
delimiter 定界符 
delinquent 拖欠帐款 
deliver 传递（回叫） 
delivery 传递 
demand 需求 
demangling 识别解码 
demodulate 解调 
demodulation 解调 
demodulator 解调器 
demographic 人口统计的 
demon 精灵程序 
demonstrate v.论证，证明，证实 
demonstration 示范 
demount 卸下 
demultiplex 多路分用 
demultiplexer 多路分用器 
denary 十进制的 
denormal 非正常表示的 
denote 表示 
density 密度 
deny 否认 
department n.部门，门类，系 
depend 取决于 
dependent 从属 
dependents 从属 
depress 按下 
depth 深度 
deque 双队列 
dequeue 离队 
derivation 派生 
descend 下降 
descendant 子代 
describe 描述 
descried a.被看到的，被发现的 
description n.描述 
descriptor 描述信息块 
deselect 取消选择 
deserialize 串行变并行 
deserializer 串并转换器 
design 设计 
designate 指定 
designated a.指定的，特指的 
designation 指定 
designlist 设计表 
desirable a.所希望的，称心的 
desire v.期望 
desired 期望的 
desk n.书桌，控制台，面板 
desktop 桌面 
desposition 支配权 
destage 离台 
destination 目的地 
destroy 毁坏 
destructor 析构成员 
detached 分离的 
detail 细节 
detailed 详细的 
detect 检测 
detent 稳定装置 
deter vt.阻止，拦住，妨碍 
determinant 行列式值 
determine 确定 
develop 开发 
developer 开发者 
developing 开发 
development n.开发，研制 
deviation 偏差 
device 设备 
diacritic 发音符号 
diacritical a.区分的，辩别的 
diaeresis 分音符 
diagnose 诊断 
diagnostic 诊断的 
diagnostics 诊断 
diagonal 对角的 
diagonally ad.斜(对) 
diagram 图表 
dial 拨号 
dialing 拨号 
dialog 对话 
dibit 双位 
dictionary 字典 
differ vi.不同，不一致 
difference 差 
different 不同的 
differentiate v.区别，分辨 
differentiator 微分器 
digest 整理 
digit 数字 
digital 数字 
digitize 数字化 
dimension 维 
dimensional n....维的 
dimensionality 维数 
diode 二极管 
diphthong 元音连字 
dipping 浸渍法 
direct 直接的 
direction 指导 
directly ad.直接地，立即 
director 导向器 
directory 目录 
dirid 目录标识符 
dirname 目录名 
Dirve 驱动器 
disable 禁用 
disabled 禁用的 
disappear vi.消失 
disassembler 反汇编器 
disc 磁盘 
discard v.删除，废除，放弃 
discarded 废弃的 
discipline 规程 
disconnect 断开 
disconnection 断开 
discrete 离散的 
discriminant 判别式 
discriminator 鉴别器 
disjunction 析取 
disk 磁盘 
diskette 软盘 
dismount 卸下 
dispatch 分派 
dispatcher 调度器 
dispersant 分散剂 
displacement 位移 
display 显示 
dispose 配置 
disposition 配置 
disregard vt.轻视,把..忽略不计 
dissector 析象器 
distinction n.区别，相异，特性 
distinguish v.区别，辨识 
distort 失真 
distortion 失真 
distribute vt.分布，配线，配给 
distributed 分布的 
distribution 分发 
dithering 抖动 
ditto 同上 
diversion 转换 
divide v.除 
dividend 被除数 
division 部分 
divisor 除数 
DLL 动态连接库 
document 文档 
documentation 文档编制 
documenting 记录 
domain 域 
DOS 磁盘操作系统 
dot 点 
double a.两倍的，成双的 
doublet 二位字节 
doubleword 双字 
down 向下 
download 卸载 
downstream 顺流 
draft 草稿 
drag 拖曳 
drawable 可绘制的 
drift 漂移 
drive 驱动器 
driver 驱动程序 
drop 放下 
drum 磁鼓 
dryer 干燥器 
dual a.对偶的，双的 
due 到期 
dumb 哑的 
dummy 哑的 
dump 转储 
duodecimal 十二进制的 
duplex 双工 
duplicate 重复 
duplication 复制 
duplicator 复印机 
durability 耐用性 
duration 持续时间 
during 在期间 
dynamic 动态 
dynamicizer 动态转换器 
echo 回显 
edge 边 
edit 编辑 
editing 编辑 
edition 版本 
editor 编辑器 
effect n.效率，作用，效能 
effective a.有效的 
effectivity 有效性 
efficiency 效率 
efficiently ad.有效地 
eigenvalue 特征值 
eject 弹出 
elaboration 加工 
elapsed vi.经过 
electronic 电子的 
electronics 电子学 
element 元素 
eliminate 消去 
ellipse 椭圆 
ellipsis n.省略符号，省略(法) 
embedded 嵌入的 
embedding 嵌入 
emboldening 增亮 
embossment 凸起 
emphasis 强调 
emphasize v.强调，着重，增强 
empty a.空，零，未占用 
emulate 仿真 
emulation 仿真 
emulator 仿真器 
emulsion 感光乳剂 
enable 允许 
encapsulation 封装 
encipher 加密器 
enclave 程序集 
enclose vt.封闭，密封，包装 
enclosure 安装箱 
encode 编码 
encoder 编码器 
encounter 遇到 
encrypt 加密 
encryption 加密 
end 末端 
endian 字节存储次序 
endpoint 端点 
engineering 工程 
enhance 增强 
enlargement 放大 
enqueue 排队 
enquiry 询问 
enroll 报名 
ensure 保证 
enter 输入 
enterprise 企业 
entire a.总体 
entirely ad.完全地，彻底地 
entity 实体 
entrance 入口 
entropy 熵 
entry 项目 
enumerator 枚举符 
environ vt.围绕，包围 
environment 环境 
environmental a.周围的，环境的 
epilogue 结尾 
epoch 戳记 
equal 等于 
equalization 均衡 
equalizer 均衡器 
equally ad.相等地，相同地 
equation 方程式 
equipment 装置 
equivalence 等价 
equivalent 等价的 
equivocation 条件信息量总平均值 
erase 擦除 
eraser 擦除器 
ergoromics 人类工程学 
erlang 厄兰 
error 错误 
escalation 逐步上升 
escape 跳出 
esoteric 机密的 
especially ad.特别(是)，尤其 
essentially ad.实质上，本来 
establish 建立 
establishment 建立 
Ethernet 以太网 
evaluate 估计 
event 事件 
every 每个 
examine v.检验，考试，审查 
example 例子 
exceed 超过 
exceeded a.过度的，非常的 
except prep.除...之外，除非 
exception 异常 
excerpt 摘录 
exchange 交换 
exclamation n.惊叹(号) 
exclude 排除 
exclusive 互斥的 
executable a.可执行的 
execute 执行 
execution 执行 
exerciser 试验程序 
exhaust v.取尽，用完 
exist 存在 
existing 现存的 
exit 退出 
expand 扩充 
expander 扩充器 
expanding a.扩展的，扩充的 
expansion n.展开，展开式 
expect vt.期望，期待，盼望 
expenditure 支出 
expenses 费用 
experience vt.试验 
experiment n.实验，试验(研究) 
experimentation n.实验(工作，法) 
expertise 专门知识 
expire v.终止，期满 
explain 说明 
explanation 说明 
explanatory a.解释(性)的 
expletive 虚词 
explicitly ad.明显地，显式地 
exponent 指数 
exponential 指数的 
exponentiation 取幂 
export 调出 
exporter 出口服务器 
exposing 曝光 
exposure 曝光度 
express a.快速的 
expression 表达式 
expunge vt.擦除，删掉 
extend 扩展 
extension 扩充 
extent 范围 
external 外部的 
extra a.特别的，额外的 
extract 抽取 
extremely ad.极端地，非常 
extremity 极限 
eyecatcher 识别序列 
face n.面，表面 
facilities 设施 
facility n.设施，装备，便利 
facsimile 传真 
factor 因子 
factorial 阶乘 
factoring 因式分解 
factorization 因式分解 
fail 失败 
failure 失败 
fallback 撤退 
false a.假(布尔值)，错误 
familiar a.熟悉的，惯用的 
familiarize vt.使熟悉，使通俗化 
family 系列 
fancy n.想象(的),精制的 
fast 快速 
fastback n.快速返回 
fasten 固定 
fastselect 快速选择 
father n.父，上层(树节点的) 
fault 故障 
feature 特征成份 
feed 馈送 
feedback 反馈 
feedboard 供纸板 
feeder 输电线 
feminine 阴性 
ferrite 铁氧体 
ferromagnetics 磁学 
fetch 取 
fiber 纤维 
field 字段 
figure 图 
file 文件 
filename 文件名 
fileset 文件集 
filespace 文件空间 
filetab 文件标记 
filing n.（文件的）整理汇集 
fill 填充 
filler 填充符 
film 薄膜 
filter 筛选程序 
final 最后的 
finally ad.终于，最后 
find 寻找 
finish 完成 
first 首先 
fix 修订 
fixed 固定的 
fixing 定影 
flag 标志 
flashing 闪亮 
flat 平面的 
flexibility 灵活性 
flicker 闪烁 
floating 浮动 
floppy n.软磁盘 
flourescent 荧光的 
flow 流动 
fluerics 流体学 
fluidic 射流的 
fluidics 射流技术 
flush 清仓 
flyback 回扫 
fold 折叠 
folder 文件夹 
folding 折叠 
folio 对开本 
follower 跟随器 
following 下列 
font 字体 
foot 英尺 
footer 脚注 
footnote 注脚 
forbidden 禁用的 
force v.力，强度 
forced a.强制的 
forecast 预测 
foreground 前台 
forget 忽略 
fork 创建子进程 
form 表格 
format 格式 
formation n.构造，结构，形成 
formatted a.有格式的 
formatter 格式化器 
formatting n.格式化 
formed a.成形 
formula 公式 
fortuitous 不规则的 
forward 向前 
fourscore n.八十 
fragment n.片段，段，分段 
fragmentation 存储残片 
fragmenting 分割 
frame 帧 
framework 框架 
framing 组帧 
franking 打印标记 
free 释放 
freeze v.冻结，结冰 
freight 运费 
frequency 频率 
frequently ad.常常，频繁地 
from 从 
frustum 截头锥体 
full 全部 
fullword 全字 
fully ad.十分，完全 
function 功能 
fundamental a.基本的，根本的 
fuse 熔凝 
fuser 熔凝器 
fusing 定影 
gain 增益 
gap 间隔 
garbage 无用信息 
gate 门 
gateway 网关 
gather 集中 
general 一般的 
generate 产生 
generation 产生 
generator 发生器 
generic 类属 
geometry 几何 
giag 千兆 
gigacycle 千兆周 
glance n.闪烁 
global 全局的 
glossary 词汇表 
glyph 图象字符 
go vi.运行，达到 
Gothic 哥特体 
grab 抓取 
gradation 灰度 
gram 克 
grant 授予 
grantee 接受者 
grantor 授予者 
granularity 颗粒度 
graph 图 
graphic 图形的 
graphically ad.用图表表示 
graphics 图形 
grave 雕刻 
gravity 重心 
grid 栅极 
groove 槽 
ground 地 
grounding 接地 
group 组 
growth 增长 
GUI 图形用户界面 
guide 指南 
guideline 指南 
halftone 半色调 
halfword 半字 
halt 停机 
handle 句柄 
handler 处理器 
handles 控键 
handling n.处理，操纵 
handset 电话听筒 
handshaking 握手 
handy 方便的 
hang v.中止，暂停，挂起 
Hanzi 汉字 
hardware 硬件 
hardwired 硬连线的 
harmonic 谐波 
Hartley 哈特利 
hashing 散列法 
head 磁头 
header 头 
heading 标题 
headphone 耳机 
heap 堆阵 
hecto 百 
hectometer 百米 
Help 帮助 
helper 帮助程序 
heuristic 试探的 
heuristics 试探 
hex 十六进制 
hexadecimal a.十六进制的 
hidden 隐藏的 
hide 隐藏 
hierarchical 分层的 
hierarchy 层次结构 
highlight 突出显示 
highlighting 突出显示 
Hiragana 平假名 
histogram 直方图 
history 历史 
hit 命中 
hits 瞬态干扰 
hm 百米 
hold 保持 
hole 孔 
holiday 假期 
Hollerith 霍勒内斯 
homologation 认可 
hook 挂钩 
hopper 送卡箱 
horizontal 水平的 
horizontally ad.水平地 
host 主机 
hotfix 热修复 
hotspot 热点 
housekeeping 内务处理 
housing 外壳 
how 如何 
hub 集线器 
humidity 湿度 
hunting 寻找 
hyperbola 双曲线 
hypertext 超文本 
hyphen n.连字符，短线 
hyphenation 字符连接 
icelandic 冰岛 
icon 图符 
iconify 图符化 
idempotent 幂等 
identical a.相等的，相同的 
identically ad.相等，恒等 
identification 标识 
identifier 标识符 
identify 标识 
idle 空闲 
ignore 忽略 
illegal 非法的 
image 图象 
imbedded 嵌入的 
imbedding 嵌入 
immediate 立即的 
impedance 阻抗 
impingement 冲击 
implement 实现 
implementation 实现 
implication 蕴含式 
implicit 隐式 
implied 隐式的 
implosion 内爆 
import 调入 
importer 进口服务器 
imprinter 印刷器 
imprinting 印刷 
improve 改进 
improvement 改进 
impulse 脉冲 
inaccessible 不可存取的 
inaccuracy 不准确度 
inactive 非活动的 
inbound 入站 
include 包括 
inclusion 包含 
inclusive a.包括的，内含的 
incoming 进入 
incompatibility 不相容 
incompatible 不兼容 
inconnector 内接符 
incorporate 合并 
incorrect 不正确 
increase v.增加，增大 
increasing 递增 
increment 增量 
incremental 增量的 
indefinitely ad.无限地，无穷地 
indent 缩排 
indentation 缩排 
indention 缩排 
independent 独立 
independently 各自地 
index 索引 
indexing 变址 
indicate vt.指示，表示 
indicator 指示符 
indirect 间接的 
indirection 间接 
indirectly ad.间接地 
individual 个别的 
individually ad.个别地，单独地 
induction 归纳法 
industrial 工业的 
industry n.工业 
inexperienced a.不熟练的，外行的 
inferiors 下级 
infinite a.无限的，无穷的 
infinity 无穷大 
influence 影响 
inform 通知 
information 信息 
inherit 继承 
inheritance 继承 
inhibit 禁止 
inhibited 禁止的 
initial 初始的 
initialization 初始化 
initialize 初始化 
initializer 初始化程序 
initially ad.最初，开头 
initiate 启动 
initiator 启动程序 
inking 墨迹式画图 
inline 直接插入的 
inlining 在线的 
input 输入 
inquiry 查询 
insert 插入 
insertion n.插入，嵌入，插页 
inside n.内部的 
inspection 检查 
install 安装 
Installable 可安装 
installation 安装 
instance 实例 
instaneous 瞬时的 
instant a.立刻的，直接的 
instantiate 实例化 
instead ad.(来)代替，当作 
instruct 指示 
instruction 指令 
instrumentation 仪表化 
insufficient a.不足的，不适当的 
insulation 绝缘 
insure v.保证，保障 
integer 整数 
integrate 集成 
integrated 集成的 
integrator 积分器 
integrity 完整性 
Intellect 才智 
intelligence 智能 
intelligent 智能的 
intend vt.打算，设计 
intense a.强烈的，高度的 
intensity 亮度 
interaction 交互 
interactive 交互式 
intercept 拦截 
intercepting 截取 
interchange 交换 
interest n.兴趣，注意，影响 
interface 界面 
interfere vi.干涉，干扰，冲突 
interference 干扰 
interlace 交错 
interleave 交错 
interlink 相互链接 
interlock 互锁 
intermediate 中间的 
intermittent 间歇性的 
intern 保留区 
internal 内部的 
internally ad.在内（部） 
international 国际的 
internationalization 国际化 
Internet 网际 
internetwork 网际 
interoperability vi n.配合动作性 
interoperable a.彼此协作的 
interpret v.解释 
interpreter 解释器 
interrelated 相关的 
interrupt 中断 
intersection 逻辑乘 
interval 间隔 
intervene vi插入，干涉 
intervention 介入 
introduce vt.引进，引导 
introduction 介绍 
invalid 无效 
invariant 不变量 
invent vt.创造，想象 
inventory 存货 
inverse 逆矩阵 
invert 翻转 
investigate 审查 
invocation 调用 
invoice 发票 
invoke 调用 
involve vt.涉及，卷入，占用 
involved a.有关的 
isolation 隔离 
issue 发出 
item 项目 
iterate 迭代 
iteration 迭代 
iterative a.迭代的,重复的 
jack 插座 
jam 堵塞 
job 作业 
joggle 轻摇 
join 汇合 
journal 日志 
journaling 日志 
joystick 控制杆 
jump 转移 
junction 连接 
justify 对齐 

kanji 汉字 
katakana 片假名 
keep 保持 
kernel 内核 
kerning 字母紧排 
key 键 
keyboard 键盘 
keycaps 键罩 
keyed a.键控的 
keylock 键锁 
keypad n.小键盘 
keypunch 键控穿孔机 
keysym 键码 
keyword 关键字 
kill 杀死（进程） 
kilo 千 
kilobyte 千字节 
kilogram 千克 
kilometer 公里 
kilowatt 千瓦 
kit 组件 
knob 握柄 
label 标号 
labeled a.有标号的 
labor 人工 
laboratory 实验室 
lag 延迟 
language 语言 
latched 锁存的 
latency 等待时间 
launch 启动 
layer 层 
layout 布局 
leaders 引线 
leading n.引导(的) 
leaf 叶 
leased 租用的 
leave 脱离 
leaves 叶 
left 向左 
legal a.合法的，法律的 
legend 图注 
lending n.借出的 
letter 字母 
level 层次 
lever 杠杆 
lexical a.辞典的，词法的 
lexically 词法上 
lexicon 辞典 
liabilities 负债额 
librarian 库管理器 
library 库 
licensed 特许的 
ligature 连字 
light 指示灯 
limit 极限限制 
limitation 限制 
limited a.有限的，（受）限制的 
line 行 
linefeed 换行 
linestyle 线型 
linewidth 线宽 
link 连接 
linkable 可链接的 
linkage 链接 
linker 链接器 
list 列表 
listen 收听 
listening 收听 
listing 列表 
literal 文字 
load 装入 
loaded 已载入（的） 
loader 装入器 
loading 装入 
local 本地的 
locale 场所 
localization 本地化 
locally 本地 
locate 找出 
locating n.定位，查找 
location 位置 
locator 定位器 
lock 加锁 
locking 锁定 
lockout 封锁 
lockup 锁定 
log 记录 
logarithm 对数 
logged a.记录的，浸透的 
logger 记录器 
logic 逻辑 
logical a.逻辑的，逻辑摶驍 
Login 登录 
logo 标志 
logoff 注销 
logon 注册 
Logout 退出 
long 长型 
loop 循环 
loopback 回送 
lost 丢失 
lowercase n.下档，小写体 
lumen 流明 
lux 勒克司 
lvalue 左值 

mach n.马赫(速度单位) 
machine 机器 
macro 宏 
macroelement 宏元素 
macroexpansion 宏指令扩充 
macrogeneration 宏产生 
macrogenerator 宏产生程序 
macroinstruction 宏指令 
macrolanguage 宏语言 
macrolibrary 宏库 
macroprogramming 宏编程 
magnitude 大小 
mail 邮件 
mailbox 邮箱 
mailer 邮件程序 
mailslot 邮件槽 
main 主 
mainframe 大型机 
mainline 主线 
maintain 维护 
maintainability 可维护性 
maintainable 可维护的 
maintenance 维护 
major a.较大的，主要的 
majority 多数 
make vt.制造，形成 
malfunction 故障 
manage 管理 
management 管理 
manager 管理器 
mandatory 必要的 
mangling 识别编码 
manifest vt.表明，显示，显现 
manipulate 操作 
manipulating v.操纵，操作 
manipulator 操纵元 
manner n.方法，样式，惯例 
mantissa 尾数 
manual 手册 
manually ad.用手，手动地 
manufacture vt.制造(业)，工业 
manufacturer 制造商 
manufacturing 制造 
manuscript 手稿 
map 映象 
mapping 映象 
margin 余量 
mark 标记 
marked a.有记号的 
marker 标记 
marketing 市场营销 
marking n.标记，记号，传号 
marshal 编组 
marshalling 编组 
masculine 阳性 
mask 掩码 
masking n.掩蔽，屏蔽 
master a.总要的，总的 
match 匹配 
matching n.匹配，调整 
material 资料 
materialization 具体化 
materialize 具体化 
math n.数学 
matrix 矩阵 
Maximize 最大化 
maximum 最大的 
MBCS 多字节字符集 
mean 平均 
means n.方法，手段 
measure 测量 
mechanism 机制 
media 媒体 
medialess 无媒介 
medium n.中等的 
mega n.兆，百万 
member 成员 
memo 便笺 
memorandum 便笺 
memory 内存 
mention vt.叙述，说到 
menu 菜单 
merge 合并 
message 信息 
metadata 元数据 
metafile 元文件 
meter 米 
method 方法 
metric 公制的 
micro a.微的,百万分之一 
microcircuit 微电路 
microcode 微码 
microcomputer 微型计算机 
microdocument 微文档 
microfiche 微缩格片 
microfilm 微缩胶卷 
microinstruction 微指令 
microprocessor 微处理器 
microprogram 微程序 
microprogramming 微程序设计 
microroutine 微例程 
microsecond 微秒 
microwave 微波 
middle 中间 
MIDI 音乐设备数字接口 
migrate 移植 
migration 移植 
mile 英里 
milli 毫 
millimeter 毫米 
millisecond 毫秒 
minidisk 小磁盘 
minimize 最小化 
minimum 最小的 
minuend 被减数 
minus a.负数，减 
mirror n.镜，反射，反映 
mirroring 镜象 
miscellaneous 多种的 
mismatch n.失配，不匹配 
missing 丢失 
mistake 错误 
mix 混合剂 
mixer 混合器 
mixture 混合体 
mnemonic 助记的 
modal 模态 
mode 方式 
model 模型 
modem 调制解调器 
modification 修改 
modified a.修改的，变更的 
modifier 修饰符 
modify 修改 
modular 模块化的 
modulate 调制 
modulation 调制 
module 模块 
modulo 模 
moment n.矩，力矩，磁矩 
monitor 监控程序 
monitoring 监控 
mono a.单音的 
monochrome 单色 
monostable 单稳的 
month 月份 
more 尚有 
motif n.主题，要点，特色 
motor 电动机 
mount 装载 
mouse 鼠标 
move 移动 
movement 移动 
multidrop 多点 
multiiplex 多路传送 
multiline 多线路 
multimedia 多媒体 
multiple 多个的 
multiplexer 多路转接器 
multiplexing 多路复用 
multiplexor 多路传送器 
multiplicand 被乘数 
multiplication 乘法 
multiplicity 复合度 
multiplier 乘数 
multipoint 多点 
multiprocessing n.多重处理，多道处理 
multiprocessor 多重处理机 
multistation 多功能站 
multitasking 多任务 
multithread 多线程 
multiwindow 多窗口 
must 必须 
mutex 互斥标记 
name 名字 
namespace 名称空间 
native 本机的 
nature 性质 
navigate v.导航，驾驶 
navigation n.导航 
navigational 引导的 
necessary 必需的 
needle 探针 
negate vt.否定,求反,摲菙 
negative a.负的，否定的 
negotiation 协商 
neper 奈培 
nest 嵌套 
nested 嵌套 
netname 网络名 
network 网络 
networking 连网 
neural 神经 
neutral 中性的 
new 新的 
nickname 别号 
node 节点 
nodes 节点 
noise 噪声 
nomenclature 术语 
nominal 额定的 
noninteractive a.不相关的，非交互的 
noninventory 非库存 
nonswitched 非交换式 
nonupdatable 不可更新的 
nonworkdays 非工作日 
nonzero 非零 
normal 正常的 
normalize 规格化 
notation 记数法 
note 注意 
notebook 笔记本 
nucleus 核心 
null 空的 
number 数 
numeral 数字 
numeration 记数 
numeric 数字的 
numerical 数字的 
numerous a.为数众多的，无数的 
object 目标对象 
obscure 模糊的 
observation 观察 
observer 观察者 
obsolete 过时的 
obstruction 障碍 
occasionally ad.偶尔(地)，不时 
occlude 堵塞 
occupation 职业 
occupy 占用 
occur 发生 
occurrence n.出现，发生 
octal 八进制的 
octet 八位位组 
odometer n.里程表，计程仪 
oersted 奥斯特 
offer v.提供，给予，呈现 
offhook 摘机 
offline 脱机 
offset 位移 
ohm 欧姆 
OK 确认 
omit vt.省略，删去，遗漏 
on-line a.联机的 
online 联机 
only 仅 
opaque 不透明的 
open 打开 
operand 操作数 
operate 操作 
operating 操作 
operation 操作 
operator 运算符 
opinion n.意见，见解，判断 
opposite a.相反的 
optimization 优化 
optimize v.优选，优化 
optimum 最优的 
option 任选项 
optional 任选的 
order 命令 
ordering 定序 
ordinal 序数 
organization 组织 
organize v.组织，创办，成立 
orientation 方位 
oriented a.有向的，定向的 
origin 起始地址 
original 原始 
originally ad.原来，最初 
oscilloscope 示波器 
other 其他 
otherwise 否则 
outcome n.结果，成果，输出 
outconnector 外接器 
outlet 插座 
outline 提纲 
output 输出 
overall 整个 
overcircle 上圈 
overcommitment 过度承诺 
overdot 上点 
overdue 逾期 
overflow 上溢 
overhead 间接制造费用 
overheat 过热 
overlap 重叠 
overlay 覆盖 
overload 超负荷 
overloading 重载 
override 覆盖 
overrun 过速 
overscan 过扫描 
overscore 顶线 
overstrike 重复打印 
overstriking 重叠打印 
overtime 加班 
overview 概述 
overwrite 覆盖 
owner 所有者 
ownership 所有权 
pace 调步 
pacing 调步 
pack 压缩 
package 包 
packet 包 
packeted 成套的 
packing 包装 
pad 填充 
padding 填充 
pagination 页调整 
paging 调页 
palette 调色板 
pane 屏面 
panel 屏面 
panning 漫游 
paragraph 段 
parallel 并行的 
parameter 参数 
parent 父代 
parentheses 括号 
parenthesis n.括弧，圆括号 
parity 奇偶性 
parse 语法分析 
parser 语法分析器 
part 部件 
participant 参与者 
particular a.特定的，特别的 
particularly ad.特别，格外，尤其 
partition 分区 
partitioned 分区的 
partner 伙伴 
pass v.传送，传递，遍(数) 
passthru 通过 
password 口令 
Paste 粘贴选项 
patch 修补 
path 路径 
pattern 模式 
pause 暂停 
payroll 工资单 
peer 同级 
pel 像素 
penalty n.惩罚，罚款，负担 
pending 暂挂 
percentage 百分率 
perforator 穿孔机 
perform 实行 
performance 性能 
period 句点 
peripheral 外围的 
permanence 永久性 
permanent 永久的 
permanently ad.永久地，持久地 
permission 许可权 
permissions 许可权 
permit 允许 
permutation 排列 
persistence 持续性 
person 人员 
personal a.个人的，自身的 
personalize 个人化 
personnel 人员 
pertain vi.附属，属于，关于 
phase 阶段 
phone 电话 
phoneme 音素 
photocell 光电池 
photoconductor 光导体 
photodetector 光检测器 
phototypesetter 照相排版 
phrase 短语 
physical 物理的 
physically a.物理上，实际上 
pick 检料 
picking 检料 
picosecond 微微秒 
picture 图形 
pin 针 
pinboard 插接板 
pipe 管道 
pipeline 管线 
piping 管道 
pitch 音调 
pixel 像素 
pixmap 象图 
placeholder 位置标志符 
placement 位置 
plaintext 明文 
plan 计划 
plane 位面 
planner 计划人员 
planning 计划 
plant 工厂 
platen 压纸卷筒 
platform n.平台 
plot 绘图 
plotter 绘图仪 
plug 插头 
point 点 
pointer 指针 
pointing 指点 
poll 轮询 
polling 轮询 
polyline 多线 
polymarker 多重指示器 
polymorphism 多形性 
pool 池 
pop 弹出 
popdown 弹下 
popup 弹出 
port 端口 
portability 可移植性 
portion n.分配 
position 位置 
positioning 定位 
positive a.正的，阳的，正片 
possibility n.可能性 
possible 可能 
possibly ad.可能地，合理地 
postamble 后同步信号 
postpone 延迟 
potentially ad.可能地，大概地 
power 电源 
powerful 功效强大的 
practice n.实习，实践 
pragma 编译指示 
pragmatics 语用学 
preamble 前同步信号 
preanalysis 预分析 
preauthorization 预先授权 
prebuild 预构建 
precede v.先于 
precedence 优先级 
preceding a.先的，以前的 
precision 精度 
precondition 先决条件 
predicate 谓词 
predict vt.预测，预言 
preemption 抢先 
preface 前言 
prefer vt.更喜欢，宁愿 
prefix 前缀 
premultiplication 左乘 
preparation 准备 
preprocessing 预处理 
preprocessor 预处理器 
prepunched 预先穿孔的 
prerequisite 先决条件 
preroll 预卷 
presence n.存在，有 
present a.提供 
presentation 呈示 
preserve vt.保存，维持 
preset 预置 
press 按 
pressed a.加压的，压缩的 
pressing n.紧急的 
prestore 预存储 
prevent v.防止，预防 
preview vt.预览 
previous a.早先的，上述的 
previously ad.以前，预先 
price n.价格 
primarily ad.首先，起初，原来 
primary 主要的 
primitive 原语 
principal 主要的 
print 打印 
printable a.可印刷的 
printer 打印机 
printing 打印 
printout 打印输出 
prior a.先验的，优先的 
priority 优先级 
private 专用 
privilege 特权 
probable a.概率的，可能的 
probably ad.多半，很可能 
problem 问题 
procedural a.程序上的 
procedure 过程 
proceed 继续 
process 进程 
processing 处理 
processor 处理器 
produce v.生产，制造 
product 产品 
production 生产 
productivity 生产力 
professional 专业人员 
profile 概要 
profiling 程序概要分析 
program 程序 
programmable a.可编程的 
programmer 程序员 
programming 程序设计 
progress n.进度，进展 
project 项目 
projection 投影 
prolog 前言 
prologue 前言 
promote 促进 
prompt 提示 
prompting 提示 
proof 证明 
proper 正确的 
properly ad.真正地，适当地 
property 特性 
proporational 均衡的 
proprietary a.专有的 
protect vt.保护 
protected 受保护 
protection 保护 
protocol 协议 
prototype 原型 
provide 提供 
pruning 修剪 
pseudo a.假的，伪的，冒充的 
pseudocolor 伪彩色 
pseudonumber 代号 
public 公共的 
publication 出版物 
publisher n.出版者，发行人 
puck 球 
pulldown 下拉 
pulse 脉冲 
purchase 采购 
purchasing 采购 
purge 清除 
purpose n.打算 
push 按 
pushbutton 按钮 
pyramid 角锥体 
quad 四芯导线 
qualified a.合格的，受限制的 
qualifier 限定词 
quality 质量 
quantization 量子化 
quantize 量化 
quantum 量子 
quark 夸克 
quartet 四位字节 
query 查询 
question n.问题 
questionaire 询问表 
queue 队列 
queuing 排队 
quiescing 停顿 
quiet 安静 
quinary 五进制的 
quintet 五位字节 
quit 退出 
quotation 引语 
quote 报价 
quotient 商 
rack 机架 
radar 雷达 
radiate 辐射 
radix 基数 
rail 导轨 
raise 提高 
RAM 随机存取存储器 
random a.随机的 
range 范围 
rank 排序 
raster 光栅 
rate 速率 
rated 额定的 
rating 额定 
rational 有理的 
reach v.范围，达到范围 
reactivate v.使恢复活动 
read 读 
readable a.可读的 
reader 阅读器 
readily ad.容易地，不勉强 
reading n.读，读数 
ready 就绪 
real 实 
reallocation 重新分配 
really a.真正地，确实地 
realm 领域 
reappear vi.再现，重现 
rear 背面 
rearrange v.重新整理，重新排序 
reason 原因 
rebinding 重新连接 
rebuild v.重建，修复，改造 
recalibrate 重新校准 
recall vt.撤消，复活，检索 
receipt 收据 
receive 接收 
received a.被接收的，公认的 
receiver 接收者 
receiving 接收 
receptacle 插座 
recipe 准则 
recipient 收件人 
reciprocal 倒数 
reclaim 收回 
reclock 重新计时 
recognize v.识别 
recommend vt.推荐，建议 
reconciliation 对帐 
reconfiguration 重新配置 
record 记录 
recorder 记录器 
recost 成本重计 
recover 恢复 
recoverable a.可恢复的，可回收的 
recovery 恢复 
rectangle 矩形 
rectangular a.矩形的 
recursion 循环 
recursive a.递归的，循环的 
redefine vt.重新规定(定义) 
redirect 重定向 
redirection 重定向 
redisplay 再显示 
redo 重做 
redraw vt.再拉 
reduce 减少 
reduction n.减化，还原，减少 
redundancy 冗余 
redundant a.冗余的 
reel 卷 
reenter v.重新进入 
reenterable 可重入的 
reentrant 可重入的 
reevaluate 重新估计 
refer 参考 
reference 引用 
referral 工作分派 
refile 接力传送 
reflect 反映 
reflection 反射 
reflow v.回流，逆流 
reformat 重新格式化 
refresh 刷新 
regard vt.考虑，注意，关系 
regardless a.不注意的，不考虑的 
regeneration 重新生成 
region 区 
register 寄存器 
registration 登记 
regression 回归 
regular a.正则的，正规的 
regulation 规则 
regulator 调节器 
reindex v.变换(改变)符号 
reinitialize 重新初始化 
reinstall 重新安装 
reinstate vt.复原，恢复 
reject 拒绝 
related a.相关的 
relation 关系 
relational 关系的 
relationship 关系 
relative 相对的 
release 释放 
reliability 可靠性 
reload vt.再装入 
relocatable 浮动 
relocate 浮动 
relocation 浮动 
remain vi.剩下，留下，仍然 
remainder 余数 
remaining 剩余的 
remark 评语 
remember v.存储，记忆，记住 
remote 远程 
remotely 远程地 
removal 除去 
remove 除去 
rename 重新命名 
render 图象产生 
renderer 描绘器 
rendering 描绘 
rendzvous 会合 
renovate 改造 
rent n.裂缝 
reorder v.(按序)排列，排序 
reorganization vt.重排，改组 
repaint vt.重画 
repair 修理 
reparent 重定父级 
repeat 重复 
repeatablity 可重复性 
repeated a.重复的 
repeatedly ad.重复地 
repeater 中继器 
repeating n.重复，循环 
reperforator 复穿孔机 
repertory 指令表 
repetitive a.重复的 
repetitor 重复词 
replace 置换 
replaceable 可置换的 
replacement n.替换，置换，更新 
replan 重新计划 
replica 副本 
replicate vt.重复，复制 
replication 复制 
reply 回答 
report 报告 
repository 仓库 
represent v.表示，表现，代表 
representation 表示法 
representative a.典型的，表示的 
reprioritize 变更优先顺序 
reproduce 复制 
reproducer 复穿孔机 
request 请求 
requester 请求器 
require 需求 
required 必需 
requirement 需求 
requisition 请求 
requisitioner 请求者 
reread vt.重读 
rerun 重新运行 
resend 再送 
reservation 保留 
reserve vt.保留，预定，预约 
reserved 保留的 
reset 复位 
reside vi.驻留 
resident 驻留 
residual 残留的 
resistance 阻抗 
resolution 分辨率 
resolve 分辨 
resolver 分解器 
resource 资源 
respect n.遵守，关系 
respectively ad.分别地 
respond v.回答，响应 
response 响应 
responsibility 责任 
rest n.剩余，休息 
restart 重新启动 
restore 复原 
restrict vt.约束，限制 
restricted a.受限制的，受约束的 
restricting n.限制(的) 
restriction 限制 
restructure vt.调整，重新组织 
result 结果 
resulting a.结果的，合成的 
resume 继续 
resynchronization 再同步 
retain vt.保持，维持 
retainer 定位器 
retrace 重新跟踪 
retransmit 重新发送 
retrieval 检索 
retrieve 检索 
retry 重试 
return 返回 
returned a.退回的 
returns 报酬 
reusable 可再用的 
reuse 再使用 
reversal 反向 
reverse 反向 
review 复查 
revise 修订 
revokable 可取消的 
revoke 取消 
revolutionize vt.变革，彻底改革 
rewind 回绕 
rework 重做 
rewrite vt.重写，再生 
RGB 红绿兰颜色表示法 
rid 资源标识符 
right 右 
rights 权利 
rigid 硬性的 
ring 环 
ringer 振铃器 
RMFS 描绘机制和格式 
robot 机器人 
roll 卷动 
roller 滚轮 
room n.房间，空间 
root 根 
rotary 旋转式 
rotating 旋转 
round 舍入 
rounding 舍入 
route 路径 
router 路由程序 
routine 例行程序 
routing 路由选择 
row 行 
rule n.规则，法则，尺 
run 运行 
running a.运行着的，游动的 
runtime n.运行时间 
S 启动／停止 
safe a.安全的，可靠的 
safely ad.安全地，确实地 
safety n.安全，保险 
salary n.发工资 
sale n.销售，销路 
salvager 拯救者 
same a.同样的，相同的 
sample 采样 
sampling 采样 
satisfy 满足 
save 保存 
saveset 保存集 
saving a.保存的 
say v.说，显示，假定 
SBCS 单字节字符集 
scalar 标量 
scale 比例尺 
scaling 比例转换 
scan 扫描 
scanline 扫描行 
scanner 扫描器 
scatter 分散 
scattered a.分散的 
schedule 调度 
scheduled 预定 
scheduler 调度程序 
schema 图解 
scheme n.方案，计划，图 
scientific 科学的 
scope 作用域 
Scout 检索程序 
scrap 报废 
scratch 擦除 
screen 屏幕 
screenhelp 屏幕求助 
screenmask 屏幕屏蔽区 
screw 螺钉 
scroll 滚动 
scrolling 卷动 
seal 封 
seamless a.无缝的 
search 搜索 
searching n.搜索 
seasonal 季节性的 
second n.秒，第二的 
secondary 次级 
section 部分 
sector 扇区 
secure 安全的 
security 安全性 
see 查看 
seek 查找 
segment 段 
segmentation 分段 
seismics 地震探测法 
seldom ad.不常，很少，难得 
select 选择 
selected a.精选的 
selecting 选择 
selection 选择 
selector 选择器 
semantic 语义 
semaphore 信号灯 
semicolon 分号 
send 发送 
sender 发送人 
sense 检测 
sensitive a.敏感的，灵敏的 
sensitivity 灵敏度 
sensor 传感器 
sentence 句子 
sentinel 标记 
separate v.各自的 
separated a.分开的 
separately ad.分别地 
separator 分隔符 
septet 七位字节 
sequence 顺序 
sequencing 定序 
sequentially ad.顺序地 
serial 串行 
serializability 串行 
serialize 串行化 
series 系列 
serve 服务 
server 服务器 
service 服务 
servicing 检修 
session 阶段作业 
set 设置 
setgid 设置组标识符 
setting 设置 
Settings 设置选项 
setuid 设置用户标识符 
setup 设置 
seven n.七(个) 
several a.若干个，几个 
severe 严重 
severity 严重性 
sextet 六位字节 
shaded 阴影 
shading 描影 
shadow 阴影 
shape 形状 
share 共享 
sheet n.(图)表，纸，片 
shell 外壳 
shield v.屏蔽，罩，防护 
shift 移位 
ship 装运 
shipment 出货 
shipping 装运 
shmid 共享存储器标识符 
short 短路 
shortcut n.近路，捷径 
should 应该 
Show 显示 
showing n.显示，表现 
shredder 碎纸机 
shut v.关闭 
shutdown 关机 
sibling 兄弟 
siblings 兄弟节点 
side 一边 
sign 正负号 
signal 信号 
signature 签名 
signed 带正负号 
significance 有效 
significand 有效位数 
significant a.有效的，有意义的 
significantly 显著地 
similar a.相似的 
simple 简单的 
simplex 单工的 
simply ad.简单地，单纯地 
simulate 模拟 
simulation 模拟 
simulator 模拟器 
simultaneous 同时的 
since prep.自从...以来 
sine 正弦 
single 单个 
sit v.位于，安装 
site 位置 
situation n.情况，状况，势态 
six n.六(个)(的) 
size 大小 
skeleton 骨架 
skew 偏斜 
skewness 偏斜度 
skill n.技巧 
skip 跳跃 
skulk 躲藏 
slash 斜线 
slave 从属 
slice 片 
slide 滑动导轨 
slider 滑动器 
slot 槽 
slow a.慢速的 
slowly ad.缓慢地 
small 小 
smooth v.平滑的 
smoothing 平滑 
smudge 污迹 
snapshot 抽点打印 
so pron.如此,这样 
social a.社会的 
socket 插座 
soft a.软的 
software 软件 
solely ad.独自，单独，只 
solid 固态的 
solution n.解，解法，解答 
solve 解决 
somewhat pron.稍微，有点 
sonar 声纳 
sort 分类 
sorter 分类程序 
sound n.声音，音响 
sounding a.发声的 
source 源 
space 空间 
spare 备用 
speaker 扬声器 
special 特殊的 
specialize v.(使)专门化 
specific 特定 
specifically ad.特别地，逐一地 
specification 规范 
specifiers 说明符 
specify 指定 
speech n.说话，言语，语音 
speed 速度 
spell v.拼写 
spelling 拼写 
spill v.漏出，溢出，漏失 
spindle 轴 
split 分割 
splitting n.分区[裂] 
spontaneous 自发的 
spool 假脱机 
spooler 假脱机程序 
spooling 假脱机 
spread v.展开，传播 
spring 弹簧 
sprite 子画面 
SQL 结构化查询语言 
square n.方形的 
squeeze v.挤压 
stability 稳定性 
stabilizer 稳定器 
stable 稳定的 
stack 堆栈 
stacker 接卡箱 
stage 阶段 
staging 登台 
stamp n.图章 
stand v.处于(状态)，保持 
standard 标准 
standardize 标准化 
standby 待用 
stanza 节 
star n.星形，星号 
start 开始 
Startable 关机后再启动 
starting a.起始的 
startup 启动 
state 状态 
stated a.规定的 
statement 语句 
static 静态的 
staticizer 静态转换器 
station 站 
stationary a.静止的，平稳的 
statistical 统计的 
statistics 统计学 
status 状态 
stay v.停止，停留 
step 步骤 
sticky 粘连的 
still a.静 v.平静 
stipple 点画 
stockout 无存货 
stockroom 库房 
stop 停止 
stopping n.停止，制动(状态) 
storage 存储器 
store 存储 
storeroom 贮藏室 
stream 流 
streaming 流型的 
stride 跨越 
strike v.敲，击 
string 字符串 
stroke 笔划 
strong a.强的 
struct 结构 
structural a.结构的，结构上的 
structure 结构 
stub 抽头 
stuff n.装入 
style 形式 
stylus 指示笔 
subaddress 子地址 
subassembly 次装配 
subchannel 子通道 
subclass 子类 
subcommand 子命令 
subcomponent 子部件 
subconsole 副控制台 
subcontractor 分包商 
subdirectory 子目录 
subfield 子字段 
subfile 子文件 
subgroup n.分组，子群 
subheading 次标题 
subheap 子堆 
subject n.主题，源 
subloop 子回路 
submenu 子菜单 
submission 提交 
submit 提交 
submode 子方式 
subnet 子网 
subnetwork 子网 
subobject 子目标 
subordinate 附属 
subpart 子部件 
subpattern 子模式 
subprocess 子进程 
subprogram 子程序 
subproject 子项目 
subqueue 子队列 
subroutine 子程序 
subscribe 签署 
subscriber 用户 
subscript 下标 
subsequent a.后来的，其次的 
subsequently ad.其后，其次，按着 
subserver 子服务 
subset 子集 
subshell 子外壳 
substantial a.实质的，真正的 
substantially ad.实质上，本质上 
substitute 替代 
substitution 替代 
substring 子串 
subsystem 子系统 
subtask 子任务 
subtotal 分合计 
subtrahend 减数 
subtree 子树 
subtype 子类型 
subunit 子单元 
successful 成功的 
succession n.逐次性，连续性 
successive a.逐次的，相继的 
successor 后续 
such a.这样的，如此 
sufficient 足够的 
suffix 后缀 
suggest vt.建议，提议，暗示 
suggestion n.暗示，提醒 
suitable a.适合的，相适宜的 
sum 和数 
summarize 概述 
summary 摘要 
sun n.太阳，日 
superblock 超级块 
supercalss 超类 
superclass 超类 
superclient 超级客户 
superimpose vt.重叠，叠加 
superobject 超对象 
superscalar 超标量 
superscript 上标 
superset 超集 
superuser 超级用户 
supervisor 管理程序 
supplier 供应商 
supplies 用品 
supply vt.电源，供给 
support 支持 
supporters 支持单元 
suppose v.假定，推测 
supposed a.假定的，推测的 
suppress 抑制 
suppressed vt.抑制，取消 
suppression 抑制 
sure 确认 
surface 表面 
surrounding a.周围的，环绕的 
survey 勘测 
suspend 暂停 
suspension n.暂停，中止，挂起 
swab 棉签 
swap 交换 
swapping 交换 
switch 开关 
switching 开关 
syllable 音节 
symbol 符号 
symmetric 对称 
symptom 症状 
synchronization 同步化 
synchronize v.使同步 
synchronous 同步的 
syndetic 连接的 
synergic 协作的 
synonym 同义词 
syntactical 语法的 
syntax 语法 
system 系统 

tab 跳位、标签 
table 表 
tablespace 表空间 
tablet 图形输入板 
tabulate 制表 
tabulator 制表机 
tachometer 转速计 
tag 标记 
tailgate 尾板 
tailor 剪裁 
take v.取，拿 
talent n.才能，技能，人才 
talk v.通话，谈话 
tape 磁带 
target 目标 
tariff 定价表 
task 任务 
tasking 任务 
teach v.教，讲授 
team n.队，小组 
technical a.技术的，专业的 
technology n.工艺，技术，制造学 
telecommunication 远程通信 
telegraph 电报 
telemeter 遥测计 
telephone 电话 
teleprinter 电传打印机 
teleprocessing 远程处理 
teletype 电传打字机 
teletypewriter 电传打字机 
Telex 用户电报 
tell n.讲，说，教，计算 
template 模板 
temporarily ad.暂时 
temporary 临时 
tension n.张力 
term 项 
terminal 终端 
terminals 终止节点 
terminate 终止 
terminating n.终止，终结，收信 
termination 端接 
terminator 端接器 
terminology 术语 
terms 付款条件 
ternary 三进制的 
test 测试 
testpoint 测试点 
text 文本 
textport 文本口 
texture 纹理 
then 然后 
thereafter ad.此后，据此 
therefore ad.因此，所以 
thesaurus 词库 
thickness 厚度 
think v.考虑，以为，判断 
third a.第三，三分之一 
this 此 
though conj.虽然，尽管 
thousand n.(一)千，无数的 
thrashing 系统颠簸 
thread 线程 
three a.三(的) 
threshold 阈值 
through prep.通过，直通 
throughout prep.贯穿，整，遍 
throughput 吞吐量 
throw 废弃 
tick 滴答 
ticket 票券 
tilde 波浪字符 
Tile 阶式 
tilt 倾斜 
time 时间 
timeout 超时 
timer 计时器 
times n.次数 
timeslicing 时间片 
timing 定时 
tiny a.微小的，微量的 
tip 倾斜 
title 标题 
today n.今天 
together ad.一同，共同，相互 
toggle 双向开关 
token 令牌 
tolerance 容错 
tone n.音调，音色，色调 
toner 增色剂 
tool 工具 
Toolkit 工具箱 
top 顶部 
topic 题目 
topology 拓扑学 
tornado n.旋风，龙卷风 
total 总计 
touch 接触 
toward prep.朝(着..方向) 
tower 塔形 
trace 跟踪 
traceback 追溯 
tracepoint 跟踪点 
track 磁道 
trademark 注册商标 
traditional a.传统的，惯例的 
traffic 通信量 
trailer 尾部 
trailing n.尾随的 
train 字列 
transaction 事务 
transceiver 收发器 
transcribe 转录 
transcriber 转录器 
transcript 副本 
transducer 变换器 
transfer 传送 
transform 变换 
transformation 变换 
transformer 变压器 
transient 瞬时 
transition 转移 
translate 翻译 
translation 翻译 
translator 转换器 
transliterate 直译 
transmission 传输 
transmit 发送 
transmitter 发送器 
transparency 透明性 
transparent 透明 
transport 传送 
transportable 可传送的 
trap 自陷 
traversal 遍历 
traverse v.横渡，横过，横断 
tray 托盘 
treat v.处理，加工 
treble 高音 
tree 树 
trend 趋势 
trigger 触发器 
triplet 三位字节 
trouble n.故障 
true a.真，实，选中 
truncate 截断 
trunk 总线 
try 尝试 
trying a.费劲的，困难的 
tube 管子 
tuning 调整 
tuple 元组 
turn v.圈，匝 
turnaround 周转 
turning a.转弯的，旋转的 
turnkey n.总控钥匙 
turnover 周转 
turquoise 青绿色 
tutorial 指导的 
twentieth n.第二十(的) 
twice n.两次，两倍于 
twinaxial 双轴 
twist 扭曲 
two n.二，两，双 
type 类型 
typeface 铅字样 
typefont 字体 
typewriter n.打字机 
typical a.典型的，标准的 

UI 用户界面接口 
umlaut 元音变音 
unable 无法 
Unassign 解除指定 
unattached 不连接的 
unattended 无人照管 
unavailable a.不能利用的 
unbind 切断 
unblock 解块 
unblocked 非块式 
unchanged a.不变的 
unclassified 非保密 
unconfigure 无配置 
undefine 未定义 
undefined a.未定义的 
under prep.在..下面(之下) 
underflow 下溢 
underline 下划线 
underload 负荷不足 
underlying a.基础的，根本的 
underscore 下划线 
undershipment 出货不足 
understand v.懂，明白(了)，理解 
understanding n.了解的，聪明的 
undesirable 　a.不合乎需要的 
undo 取消 
undone a.未完成的 
unescaped 非转义 
unexport 非输出 
unformat 未定格式 
unformatted a.无格式的 
unfortunately ad.不幸，遗憾地 
union 联合 
unique 唯一的 
unit 单元 
university n.(综合性)大学 
unknown a.未知的，无名的 
unlabled 无标号的 
unless conj.除非 
unlike a.不象的，不同的 
unlink 解链 
unload 卸出 
unloaded 已卸载 
unlock 解锁 
unmark 取消标记 
unmarked a.没有标记的 
unmarshal 数据编出 
unmarshalling 数据编出 
unmirror 取消镜象 
unmount 卸下 
unnecessary a.不必要的，多余的 
unpack 拆开 
unpredictable 不可预测 
unrecognized a.未被认出的 
unsave v. 不储存 
unshift v.未移动，不移档 
unsigned a.无符号的 
unsuccessful a.不成功的，失败的 
until prep.到..为止，直到 
unused a.不用的，空着的 
unviewable 不可视 
unwanted a.不需要的，多余的 
up 向上 
upcall 上叫 
update 更新 
updated a.适时的，更新的 
upgrade 升级 
upload 上载 
upon prep.依据，遵照 
upper a.上的，上部的 
uppercase n.大写字母 
upserver 更新服务器 
upstream 上游 
usage n.应用，使用，用法 
use 使用 
useful a.有用的 
useless a.无用的 
user 用户 
userid 用户标识符 
usertime 用户时间 
usually ad.通常，平常，一般 
utility 实用程序 
utilization 使用率 
vacuum 真空 
valid 有效的 
validate 验证 
validation 验证 
validity 有效性 
valuable a.有价值的，贵重的 
valuator 定值器 
value 值 
variable 变量 
variance 方差 
variant 变体 
variety n.变化，种类，品种 
various 各种的 
vary 转换 
varying a.变化的，可变的 
VCR 录像机 
vector 向量 
vendor 供应商 
verb 动词 
verification 验证 
verifier 校对机 
verify 验证 
version 版本 
vertical 垂直的 
vertically ad.竖直地，直立地 
VGA 视频图形适配器 
via prep.经过，经由 
vice n.缺点，毛病，错误 
video 视频 
videodisc 影碟 
view 显示方式 
viewable 可视 
viewport 观察口 
violate vt.违犯，妨碍，破坏 
violation 违反 
virtual 虚拟的 
virtually ad.实际上 
visibility 可见性 
visible 可见的 
visitor 访问器 
visual 视觉的 
vital a.生动的，不可缺少的 
vocabulary 词汇表 
vocoder 声码器 
void 空 
volatile 易失的 
volatility 变更率 
volt 伏 
voltage 电压 
volume 音量 
vowel n.元音，母音 
wafer 圆片 
wait 等待 
waiting a.等待的 
want v.需要，应该，缺少 
ware n.仪器，商品 
warehouse 仓库 
warn vt.警告，警戒，预告 
warning 警告 
warranty n.保证(书)，授权 
watch n.监视，观测 
Watchpoint 检测点 
watertight 不漏水的 
watt 瓦 
waveform 波形 
way n.路线，途径，状态 
weatherproof 不受气候影响的 
week 周 
weight 权 
welcome vt.欢迎 
well n.好，良好 
whatever pron.无论什么 
when 当 
whenever ad.随时 
whereas conj.面，其实，既然 
whether conj.无论，不管 
whichever a.无论哪个 
whole 整个 
wick 油心 
widening 扩大 
width 宽度 
wildcard 通配符 
will 将 
window 窗口 
windowing 开窗口 
wire 导线 
wiring 接线 
withdraw 撤回 
within prep.在..以内 
without prep.没有，在..以外 
word n.著名文字编辑软件 
wordperfect n.一种曾经最流行的文字编辑软件 
work 工作 
Workarea 工作区 
workday 工作日 
workgroup 工作组 
workshop 实习 
workstation 工作站 
wrap 环绕 
write 写入 
writemask 写屏蔽 
writer 写入器 
year 年 
zap v.迅速离去，击溃 
zero n.零，零位，零点 
zeroize 填零 
zip 邮递区号 
zone 区 
zoom v.变焦距 


# 一百个绝佳句型


<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>

1.i’m an office worker. 我是上班族。 
2.i work for the government. 我在政府机关做事。 
3.i’m happy to meet you. 很高兴见到你。 
4.i like your sense of humor. 我喜欢你的幽默感。 
5.i’m glad to see you again. 很高兴再次见到你。 
6.i’ll call you. 我会打电话给你。 
7.i feel like sleeping/ taking a walk. 我想睡/散步。 
8.i want something to eat. 我想吃点东西。 
9.i need your help. 我需要你的帮助。 
10.i would like to talk to you for a minute. 我想和你谈一下。 
11.i have a lot of problems. 我有很多问题。 
12.i hope our dreams come true. 我希望我们的梦想成真。 
13.i’m looking forward to seeing you. 我期望见到你。 
14.i’m supposed to go on a diet / get a raise. 我应该节食/涨工资。 
15.i heard that you’re getting married. congratulations.听说你要结婚了，恭喜！ 
16.i see what your mean. 我了解你的意思。 
17.i can’t do this. 我不能这么做。 
18.let me explain why i was late. 让我解释迟到的理由。 
19.let’s have a beer or something. 咱们喝点啤酒什么的。 
20.where is your office? 你们的办公室在哪？ 
21.what is your plan? 你的计划是什么？ 
22.when is the store closing? 这家店什么时候结束营业？ 
23.are you sure you can come by at nine? 你肯定你九点能来吗？ 
24.am i allowed to stay out past 10? 我可以十点过后再回家吗？ 
25.the meeting was scheduled for two hours, but it is now over yet. 会议原定了两个小时，不过现在还没有结束。 
26.tom’s birthday is this week. 汤姆的生日就在这个星期。 
27.would you care to see it/ sit down for a while? 你要不要看/坐一会呢？ 
28.can you cover for me on friday/help me/ tell me how to get there? 星期五能不能    请你替我个班/你能帮我吗/你能告诉我到那里怎么走吗？ 
29.could you do me a big favor? 能否请你帮我个忙？ 
30.he is crazy about crazy english. 他对疯狂英语很着迷。 
31.can you imagine how much he paid for that car?你能想象他买那车花了多少钱吗？ 
32.can you believe that i bought a tv for $25? 
33.did you know he was having an affair/cheating on his wife? 你知道他有外遇了吗？/欺骗他的妻子吗？ 
34.did you hear about the new project? 你知道那个新项目吗？ 
35.do you realize that all of these shirts are half off? 你知道这些衬衫都卖半价了吗？ 
36.are you mind if i take tomorrow off? 你介意我明天请假吗？ 
37.i enjoy working with you very much. 我很喜欢和你一起工作。 
38.did you know that stone ended up marrying his secretary? 你知道吗？斯通最终和他的秘书结婚了。 
39.let’s get together for lunch. 让我们一起吃顿午餐吧。 
40.how did you do on your test?　你这次考试的结果如何？ 
41.do you think you can come? 你认为你能来吗？ 
42.how was your weekend ? 你周末过得怎么样？ 
43.here is my card. 这是我的名片。 
44.he is used to eating out all the time. 他已经习惯在外面吃饭了。 
45.i’m getting a new computer for birthday present. 我得到一台电脑作生日礼物。 
46.have you ever driven a bmw? 你有没有开过“宝马”？ 
47.how about if we go tomorrow instead? 我们改成明天去怎么样？ 
48.how do you like hong kong? 你喜欢香港吗？ 
49.how do you want your steak? 你的牛排要几分熟？ 
50.how did the game turn out? 球赛结果如何？ 
51.how did mary make all of her money? 玛丽所有的钱是怎么赚到的？ 
52.how was your date? 你的约会怎么样？ 
53.how are you doing with your new boss? 你跟你的新上司处得如何？ 
54.how should i tell him the bad news? 我该如何告诉他这个坏消息？ 
55.how much money did you make?　你赚了多少钱？ 
56.how much does it cost to go abroad? 出国要多少钱？ 
57.how long will it take to get to your house? 到你家要多久？ 
58.how long have you been here?　你在这里多久了？ 
59.how nice/pretty/cold/funny/stupid/boring/interesting. 
60.how about going out for dinner? 出去吃晚餐如何？ 
61.i’m sorry that you didn’t get the job. 很遗憾，你没有得到那份工作。 
62.i’m afraid that it’s not going to work out. 我恐怕这事不会成的。 
63.i guess i could come over. 我想我能来。 
64.is it okay to smoke in the office? 在办公室里抽烟可以吗？ 
65.it was kind of exciting. 有点剌激。 
66.i know what you want. 我知道你想要什么。 
67.is that why you don’t want to go home? 这就是你不想回家的原因吗？ 
68.i’m sure we can get you a great / good deal. 我很肯定我们可以帮你做成一笔好交易。 
69.would you help me with the report? 你愿意帮我写报告吗？ 
70.i didn’t know he was the richest person in the world.我不知道他是世界上最有钱的人。 
71.i’ll have to ask my boss/wife first.我必须先问一下我的老板/老婆。 
72.i take it you don’t agree. 这么说来，我认为你是不同意。 
73.i tried losing weight, but nothing worked. 我曾试着减肥，但是毫无效果。 
74.it doesn’t make any sense to get up so early.那么早起来没有任何意义。 
75.it took years of hard work to speak good english. 讲一口流利的英语需要多年的刻苦操练。 
76．it feels like spring/ i’ve been here before. 感觉好象春天到了/我以前来过这里。 
77．i wonder if they can make it. 我在想他们是不是能办得到。　 
78．it’s not as cold / hot as it was yesterday. 今天不想昨天那么冷/热。 
79.it’s not his work that bothers me; it’s his attitude. 困扰我的不是他的工作，而是他的态度。 
80.it sounds like you enjoyed it. 听起来你好象蛮喜欢的。 
81.it seems to me that be would like to go back home. 我觉得他好象想要回家。 
82.it looks very nice. 看起来很漂亮。 
83.is everything under control? 一切都在掌握之中吗？ 
84.i thought you could do a better job. 我以为你的表现会更好。 
85.it’s time for us to say “no” to america. 是我们对美国说不的时候了。 
86.the show is supposed to be good. 这场表演应当是相当好的。 
87.it really depends on who is in charge. 那纯粹要看谁负责了。 
88.it involves a lot of hard work. 那需要很多的辛勤工作。 
89.that might be in your favor. 那可能对你有利。 
90.i didn’t realize how much this meant to you. 我不知道这对你的意义有这么大。 
91.i didn’t mean to offend you. 我不是故意冒犯你。 
92.i was wondering if you were doing anything this weekend. 我想知道这个周末你有什么要做。 
93.may i have your attention., please? 请大家注意一下。 
94.this is great golfing / swimming/ picnic weather. 这是个打高尔夫球/游泳/野餐的好天气。 
95.thanks for taking me the movie. 谢谢你带我去看电影。 
96.i am too tired to speak. 我累得说不出活来。 
97.would you tell me your phone number? 你能告诉我你的电话号码吗？ 
98.where did you learn to speak english? 你从哪里学会说英语的呢？ 
99.there is a tv show about aids on right now. 电视正在播放一个关于爱滋病的节目。 
100.what do you think of his new job/ this magazine? 你对他的新工作/这本杂志看法如何？
# 李阳英语365句


<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>

1.absolutely.
(用于答话）是这样;当然是;正是如此;绝对如此。
2.absolutelyimpossible!
绝对不可能的！
3.allihavetodoislearnenglish.
我所要做的就是学英语。
4.areyoufreetomorrow?
你明天有空吗?
5.areyoumarried?
你结婚了吗？
6.areyouusedtothefoodhere?
你习惯吃这儿的饭菜吗？
7.becareful.
小心／注意。
8.bemyguest.
请便／别客气。
9.betterlatethannever.
迟到总比不到好。
10.betterlucknexttime.
祝你下一次好运。
11.bettersafethansorry.
小心不出大错。
12.canihaveadayoff?
我能请一天假吗？
13.canihelp?
要我帮忙吗？
14.canitakeamessage?
要我传话吗？
15.canitakearaincheck?
你能改天再请我吗？
16.canitakeyourorder?
您要点菜吗？
17.canyougivemeawake-upcall?
你能打电话叫醒我吗？
18.canyougivemesomefeedback?
你能给我一些建议吗？
19.canyoumakeit？
你能来吗？
20.canihaveawordwithyou?
我能跟你谈一谈吗？
21.cathmelater.
过会儿再来找我。
22.cheerup!
高兴起来！振作起来！
23.comeinandmakeyourselfathome.
请进，别客气。
24.couldihavethebill,please?
请把账单给我好吗？
25.couldyoudropmeoffattheairport?
你能载我到飞机场吗？
26.couldyouspeakslower?
你能说得慢一点吗？
27.couldyoutakeapictureforme?
你能帮我拍照吗？
28.didyouenjoyyourflight?
你的飞行旅途愉快吗？
29.didyouhaveagooddaytoday?
你今天过得好吗?
30.didyouhaveaniceholiday?
你假期过得愉快吗？
31.didyouhavefun？
你玩得开心吗？
32.dinnerisonme.
晚饭我请客。
33.doyouhavearoomavailable?
你们有空房间吗？
34.doyouhaveanyhobbies?
你有什么爱好？
35.doyouhavesomechange?
你有零钱吗？
36.doyoumindmysmoking?
你介意我抽烟吗？
37.doyouoftenworkout?
你经常锻炼身体吗？
38.doyouspeakenglish?
你会说英语吗？
39.don'tbesomodest.
别这么谦虚。
40.don'tbother.
不用麻烦了。
41.don'tgetmewrong.
别误会我。
42.don'tgiveup.
别放弃。
43.don'tjumptoconclusions.
不要急于下结论。
44.don'tletmedown.
别让我失望。
45.don'tmakeanymistakes.
别出差错。
46.don'tmentionit.
不必客气。
47.don'tmisstheboat.
不要坐失良机。
48.don'ttakeanychances.
不要心存侥幸。
49.don'ttakeitforgranted.
不要想当然。
50.don'tworryaboutit.
别担心。
51.easycome,easygo.
来得容易，去得快。
52.enjoyyourmeal.
请慢慢享用吧。
53.easiersaidthandone.
说是容易做时难。
54.firstcome,firstserved.
捷足先登。
55.forhereortogo?
再这儿吃还是带走？
56.forgetit.
算了吧。
57.forgiveme.
请原谅我。
58.givemeacall.
给我打电话。
59.givemybesttoyourfamily.
代我向你们全家问好。
60.havehimreturnmycall.
让他给我回电话。
61.haveyoueverbeentojapan?
你去过日本吗？
62.haveyoufinishedyet?
你做完了吗？
63.haveyougotanythinglarger?
有大一点儿的吗？
64.haveyougotthat?
你明白我的意思吗？
65.haveyouheardfrommary?
你收到玛丽的来信吗？
66.heisinconference.
他正在开会。
67.helpyourself,please.
请自己用。
68.holdyourhorses.
耐心点儿。
69.howcanigetintouchwithyou?
我怎样能跟你联络上？
70.howdoilook?
我看上去怎么样？
71.howisitgoing?
情况怎么样？
72.howlateareyouopen?
你们营业到几点？
73.howlongdiditlast?
持续了多久？
74.howlongwillittakemetogetthere?
到那儿要多长时间？
75.howmuchisit?
多少钱？
76.howoftendoyoueatout?
你个多就在外面吃一次饭？
77.iapologize.
我很抱歉。
78.iappreciateyourinvitation.
感谢你的邀请。
79.iassureyou.
我向你保证。
80.ibetyoucan.
我确信你能做到。
81.icanmanage.
我自己可以应付。
82.ican'taffordit.
我买不起。
83.ican'tbelieveit.
我简直不敢相信。
84.ican'tresistthetemptation.
我不能抵挡诱惑。
85.ican'tstandit.
我受不了。
86.ican'ttell.
我说不准。
87.icouldn'tagreemore.
我完全同意。
88.icouldn'tgetthrough.
我打不通电话。
89.icouldn'thelpit.
我没有办法。
90.ididn'tmeanto.
我不是故意的。
91.idon'tknowforsure.
我不能肯定。
92.ienjoyyourcompany.
我喜欢有你做伴。
93.ienjoyeditverymuch.
我非常喜欢。
94.ienvyyou.
我羡慕你。
95.ifeellikehavingsomedumplings.
我很想吃饺子。
96.ifeelterribleaboutit.
太对不起了。
97.ifeelthesameway.
我也有同感。
98.ihaveacomplaint.
我要投诉。
99.ihavenothingtodowithit.
那与我无关。
100.ihaven'ttheslightestidea.
我一点儿都不知道。
101.ihopeyou'llforgiveme.
我希望你能原谅我。
102.iknowthefeeling.
我知道那种感觉。
103.imeanwhatisay.
我说话算数。
104.ioweyouone.
我欠你一个人情。
105.ireallyregretit.
我真的非常后悔。
106.isupposeso.
我想是这样。
107.ithoughtso,too.
我也这样以为。
108.iunderstandcompletely.
我完全明白。
109.iwanttoreportatheft.
我要报一宗盗窃案。
110.iwanttoreservearoom.
我想预定一个房间。
111.iwasjustabouttocallyou.
我正准备打电话给你。
112.iwasmoved.=iwastouched.
我很受感动。
113.iwasn'tawareofthat.
我没有意识到。
114.iwasn'tbornyesterday.
我又不是三岁小孩。
115.iwishicould.
但愿我能。
116.iwouldn'tworryaboutit,ifiwereyou.
如果我是你，我就不会担心。
117.i'dlikearefund.
我想要退款。
118.i'dliketodepositsomemoney.
我想存点儿钱。
119.i'dliketomakeareservation.
我想订票。
120.i'llberightwithyou.
我马上就来。
121.i'llcheckit.
我去查一下。
122.i'lldomybest.
我将会尽我最大努力。
123.i'llgetit.
我去接电话。
124.i'llgiveyouahand.
我来帮助你。
125.i'llhavetoseeaboutthat.
这事儿我得想一想再定。
126.i'llkeepmyeyesopen.
我会留意的。
127.i'llkeepthatinmind.
我会记住的。
128.i'llpickupthetab.
我来付帐。
129.i'llplayitbyear.
我将随兴而定。
130.i'llseewhaticando.
我看一看能怎么办。
131.i'llshowyou.
我指给你看。
132.i'lltakecareofit.
我来办这件事。
133.i'lltakeit.
我要了。
134.i'lltakeyouradvice.
我接受你的忠告。
135.i'llthinkitover.
我仔细考虑一下。
136.i'lltreatyoutodiner.
我想请你吃晚饭。
137.i'llwalkyoutothedoor.
我送你到门口。
138.i'mbroke.
我身无分文。
139.i'mcrazyaboutenglish.
我非常喜欢英语。
140.i'measytoplease.
我很随和。
141.i'mgladtohearthat.
听到这消息我很高兴。
142.i'mgladyouenjoyedit.
你喜欢我就高兴。
143.i'mgoodatit.
我做这个很在行。
144.i'minagoodmood.
我现在心情很好。
145.i'mingoodshape.
我的身体状况很好。
146.i'mjusthavingalook.
我只是随便看看。
147.i'mlookingforapart-timejob.
我正在找兼职工作。
148.i'mlookingforwardtoit.
我盼望着这件事。
149.i'mlost.
我给搞糊涂了。
150.i'mnotfeelingwell.
我感觉不舒服。
151.i'mnotmyselftoday.
我今天心神不宁。
152.i'mnotreallysure.
我不太清楚。
153.i'monadiet.
我正在节食。
154.i'monmyway.
我这就上路。
155.i'mpressedfortime.
我赶时间。
156.i'msorryi'mlate.
对不起，我迟到了。
157.i'msorrytohearthat.
听到这个消息我感到很遗憾。
158.i'munderalotofpressure.
我的压力很大。
159.i'mworkingonit.
我正在努力。
160.i'vechangedmymind.
我已经改变主意。
161.i'vegotaheadache.
我头痛。
162.i'vegotmyhandsfull.
我手头正忙。
163.i'vegotnewsforyou.
我要告诉你一个好消息。
164.i'vegotnoidea.
我不知道。
165.i'vehadenough.
我已经吃饱了。
166.ifiwereinyourshoes.
如果我站在你的立场上。
167.isthatok?
这样可以吗？
168.isthisseattaken?
这位子有人坐吗？
169.italldepends.
视情形而定。
170.itcanhappentoanyone.
这事可能发生在任何人身上。
171.itdoesn'tmakeanydifference.
都一样。
172.itdoesn'tmattertome.
这对我来说无所谓。
173.itdoesn'twork.
它出故障了。
174.itdrivesmecrazy.
他使我快要发疯了。
175.itisn'tmuch.
这是微不足道的。
176.itreallycomesinhandy.
有了它真是方便。
177.itslippedmymind.
我不留神忘了。
178.ittakestime.
这需要时间。
179.itwillcometome.
我会想起来的。
180.itwilldoyougood.
这会对你有好处。
181.itwon'thappenagain.
下不为例。
182.itwon'ttakemuchtime.
不会发很多时间的。
183.itwon'twork.
行不通。
184.it'snicemeetingyou.
很高兴认识你。
185.it'sadeal.
一言为定。
186.it'salongstory.
真是一言难尽。
187.it'sanicedaytoday.
今天天气很好。
188.it'saonceinalifetimechance.
这是一生难得的机会。
189.it'sapainintheneck.
这真是苦不堪言。
190.it'sapieceofcake.
这很容易。
191.it'sasmallworld.
这世界真小。
192.it'sawasteoftime.
这是浪费时间。
193.it'sabouttime.
时间差不多了／是时候了。
194.it'sallmyfault.
都是我的错。
195.it'sawesome.
棒极了。
196.it'sawful.
真糟糕。
197.it'sbeenalongtime.
好久不见。
198.it'sbetterthannothing.
总比没有好。
199.it'sessential.
这是必要的。
200.it'shardtosay.
很难说。
201.it'sincredible.
令人难以置信／不可思议。
202.it'sjustwhatihadinmind.
这正是我想要的。
203.it'smypleasure.
这是我的荣幸。
204.it'snobigdeal.
这没什么大不了的。
205.it'snotyourfault.
不是你的错。
206.it'snothing.
小事情／不足挂齿。
207.it'sonlyamatteroftime.
这只是时间问题。
208.it'soutofthequestion.
这是不可能的。
209.it'stimefordinner.
该吃晚饭了。
210.it'supintheair.
尚未决定。
211.it'suptodate.
这个很时兴。
212.it'suptoyou.
一切由你决定。
213.it'sverypopular.
他很受欢迎。
214.it'sworthseeing.
它绝对值得一看。
215.justletitbe.
就这样吧。
216.justtobeonthesafeside.
为安全起见。
217.keepthechange.
不用找了。
218.keepupthegoodwork.
再接再厉。
219.keepyourfingerscrossed.
为成功祈祷吧。
220.killtwobirdswithonestone.
一举两得。
221.letmegetbacktoyou.
我过一会儿打给你吧。
222.letmeguess.
让我猜一猜。
223.letmeputitthisway.
让我这么说吧。
224.letmesee.
让我想一想。
225.let'scallitaday.
我们今天就到这儿吧。
226.let'scelebrate!
让我们好好庆祝一下吧！
227.let'sfindout.
我们去问一下吧。
228.let'sgettothepoint.
让我们言归正传。
229.let'sgettogethersometime.
有时间我们聚一下吧。
230.let'shopeforthebest.
让我们往好处想吧。
231.let'skeepintouch.
让我们保持联系。
232.let'smakeup.
让我们言归于好吧。
233.let'sgovisitthem.
让我们去拜访他们吧。
234.let'stalkoverdinner.
我们边吃边谈吧。
235.longtimenosee.
好久不见。
236.lookbeforeyouleap.
三思而后行。
237.mayiaskyouaquestion?
我可以问一个问题吗？
238.mayihaveareceipt?
我可以要一张收据吗？
239.mayihaveyourname,please?
请问你叫什么名字？
240.mayipaybycreditcard?
我可以用信用卡付款吗？
241.mayitryiton?
我能试穿一下吗？
242.maybeitwillwork.
也许这个办法会有效。
243.maybesomeothertime.
也许下一次吧。
244.mymouthiswatering.
我在流口水了。
245.myphonewasoutoforder.
我的电话坏了。
246.nopain,nogain.
不劳则无获。
247.noproblem.
没问题。
248.nothingisimpossibletoawillingheart.
心之所愿，无事不成。
249.painpastispleasure.
过去的痛苦即是快乐。
250.pleaseacceptmyapology.
请接受我的道歉。
251.pleasedon'tblameyourself.
请不要责怪你自己。
252.pleaseleavemealone.
请别打扰我。
253.pleaseletmeknow.
请告诉我一声。
254.pleasemakeyourselfathome.
请别客气。
255.pleaseshowmethemenu.
请把菜单给我。
256.probably.
可能吧。
257.sofar,sogood.
到目前为止还好。
258.somethingmustbedoneaboutit.
必须得想个办法。
259.something'scomeup.
发生了一些事。
260.stormsmaketreestakedeeperroots.
风暴使树木深深扎根。
261.suityourself.
随你便。
262.takecare.
请多保重。
263.takeitorleaveit.
要不要由你。
264.takemywordforit.
相信我的话。
265.takeyourtime.
慢慢来。
266.thankyouallthesame.
不管怎样还是要谢谢你。
267.thankyouforeverything.
感谢你做的一切。
268.thanksamillion.
非常感谢。
269.thanksforthewarning.
谢谢你的提醒。
270.thanksforyourcooperation.
多谢合作。
271.thatcouldn'tbebetter.
那再好不过了。
272.thatdepends.
看情况。
273.thatmakessense.
那可以理解。
274.thatremindsme.
那可提醒我了。
275.thatringsabell.
我总算想起来了。
276.thatsoundslikeagoodidea.
那听上去是个好主意。
277.that'sallright.
没关系。
278.that'sdisgusting.
真讨厌。
279.that'sfair.
那样公平。
280.that'sforsure.
那是肯定的。
281.that'sgoodtoknow.
幸好知道了这件事。
282.that'sjustwhatiwasthinking.
我也是这么想的。
283.that'slife.
这就是生活。
284.that'smorelikeit.
那样才像话。
285.that'snotaproblem.
那没问题。
286.that'snottrue.
那是不对的。
287.that'sok.
可以。
288.that'sridiculous.
那太荒唐了。
289.that'sthewayilookatit,too.
我也是这么想。
290.that'sthewayitis.
就是这么回事。
291.that'sworthwhile.
那是值得的。
292.thesametoyou.
你也一样。
293.theshortestanswerisdoing.
最简短的回答是干。
294.thesooner,thebetter.
愈快愈好。
295.thereisacallforyou.
有你的电话。
296.thereisnodoubtaboutit.
那是毫无疑问的。
297.thereisnothingicando.
我无能为力。
298.there'sapossibility.
有这个可能。
299.thesethingshappenallthetime.
这是常有的事。
300.thissouptastesgreat.
这个汤非常美味。
301.timeismoney.
时间就是金钱。
302.tomorrownevercomes.
莫依赖明天。
303.twoheadsarebetterthanone.
人多智广。
304.weareinthesmeboat.
我们的处境相同。
305.wecangetby.
我们过得去。
306.wecanworkitout.
我们可以解决这个问题。
307.wehavealotincommon.
我们有很多相同之处。
308.we'llsee.
再说吧。
309.whatacoincidence!
真是太巧了！
310.whatashame!
真是遗憾！
311.whatareyouupto?
你在忙什么呢？
312.whatareyoutalkingabout?
你在说什么?
313.whatareyourplansfortheweekend?
你周末计划做什么？
314.whatcanidoforyou?
要我帮忙吗？
315.whatdoyoudoforrelaxation?
你做什么消遣？
316.whatdoyourecommend?
你推荐什么？
317.whatdoyouthinkofmynewcar?
你觉得我的新车怎么样？
318.whatdoyouthinkofit?
你觉得怎么样？
319.whatisitabout?
这是关于什么的？
320.whatisitlikethere?
那儿怎么样？
321.whatmakesyousayso?
你怎么这么说？
322.what'sgoingon?
发生什么事了？
323.what'sonyourmind?
你在想什么呢？
324.what'sthedeadline?
截止到什么时候？
325.what'sthematterwithyou？
你怎么啦？
326.what'sthepurposeofyourvisit？
你来访的目的是什么？
327.what'stheweatherlike?
天气怎么样？
328.what'syourfavoritefood?
你最喜欢的食物是什么？
329.what'syourjob?
你做什么工作？
330.whateveryouthinkisfinewithme.
我随你。
331.whenisthemostconvenienttimeforyou?
你什么时候最方便？
332.whenwillitbeready?
什么时候能准备好？
333.whereareyougoing?
你去哪儿？
334.wherecanicheckin?
在那儿办理登记手续?
335.wherecanigoforhelp?
我该怎么办？
336.wheredoyoulive?
你住在哪儿？
337.wherehaveyoubeen?
你去哪儿了？
338.whereistherestroom,please?
请问洗手间在哪儿？
339.wherewerewe?
我们说到哪儿了？
340.whoisinchargehere?
这里谁负责？
341.wouldyoucareforadrink?
你要不要来点儿喝的？
342.wouldyoudomeafavor?
你能帮我一个忙吗？
343.youarejustsayingthat.
你只是说说而已。
344.youarekidding.
你开玩笑吧。
345.youaresoconsiderate.
你真有心。
346.youcancountonme.
你可以指望我。
347.youcansaythatagain.
我同意。
348.youcan'tcomplain.
你该知足了。
349.youdeserveit.
这是你应得的。
350.youdidagoodjob.
你干得很好。
351.yougetwhatyoupayfor.
一分钱一分货。
352.yougotagooddeal.
你买得真便宜。
353.youneedavacation.
你需要休息。
354.youneverknow.
世事难料。
355.yousaidit.
你算说对了。
356.youshouldgiveitatry.
你应该试一试。
357.youshouldtakeadvantageofit.
你应该好好利用这个机会。
358.youwillbebetteroff.
你的状况会好起来的。
359.youwillhavetowaitandsee.
你得等一等看。
360.you'llgetusedtoit.
你会习惯的。
361.you'vedialedthewrongnumber.
你拨错电话号码了。
362.you'vegotapointthere.
你说的有道理。
363.you'vegotit.
你明白了。
364.you'vemadeagoodchoice.
你的眼力不错。
365.yoursatisfactionisguaranteed.
包你满意


# 托福听力常用短语
p.a. (paper ass) 没头脑的人 

packed like sardines 拥挤得象沙丁鱼罐头一样 

packed snow 路上被踩过的雪 

paddle one's own canoe 独自闯出自己的前途 

pain in the neck 极讨厌的人或物 

paint the town red 疯狂地庆祝 

particular about food 对食物很讲究 

pass away 过世 

pass out 昏倒;分发 

pass over 忽略 

past master 技艺精湛的人 

pay down (分期付款)付头款 

pay one's own way 各自付费 

pay the price 付出代价;得到报应 

penny for your thoughts. 告诉我你想什么 

perhaps some other day 改天吧. 

Perish the thought! 打消这念头! 

person after my own heart 他人的作为符合我的心意 

pick holes 挑毛病 

pick sb out 看中某人 

pick up 一点点学习 

pick-me-up 喝酒、汤等刺激一下神经 

pipe course 容易的课程或工作 

pipe down 安静些 

plain home cooking 家常便饭 

plain sailing 一帆风顺;轻而易举之事 

play ball with 与...合作 

play it straight 诚实 

play truant 逃学 

plenty of fish in the sea 比喻多得很 

plug along 为生活而拼命工作 

poorly off 穷困潦倒 

pot calling the kettle black 五十步笑百步 

pour oil on troubled waters 平息事态 

prices are soaring 物价飞涨 

pull a long face 拉长脸不悦 

pull a long oar 独自去作 

pull no punches 不客气,动真格的 

pull off 成功;完成 

pull one's leg 开某人的玩笑 

pull oneself together 恢复镇定 

pull through 克服困难;恢复健康 

push one's luck 在已有利情况下做多余冒险 

put an end to 结束 

put aside 储蓄 

put heads together 一起商讨问题 

put heat on 对某人要求严厉 

put it on the cuff 赊帐 

put it this way 这样说;这样做 

put off 延期 

put on a show 假装给人家看 

put on weight 胖了 

put one out of the way 杀某人 

put one's foot down 坚决反对 

put one's foot in it 说错话 

put one's foot in one's mouth 说错话 

put one's heart and soul in sth 全心全意做某事 

put sb in charge of 让某人负责某事 

put sb in the ring 和某人赛一场 

put that in one's pipe and smoke it 威胁别人好好想清楚 

put through 接通电话;做妥一件工作 

put up 举起;住宿 

put up a good show 好好表现自己 

put up with 忍受 

put your best foot forward 尽量使你的仪容整洁 

quality work 细活儿 

queer(strange) fish 怪人 

quit smocking 戒烟 

quite all right 没关系 

rain or shine 不论晴雨 

rainy day 贫苦困难的日子 

raise hell 破口大骂 

raise the roof 变得异常愤怒 

really something 了不起 

red tape 官样文章 

red tape 繁文缛节 

reflect on 回忆 

regular guy 好人,靠得住的人 

released from, be 被释放;解脱 

remember sb to another 代某人问候别人 

right down one's alley 正好是某人所精通的 

right or wrong 无论如何 

right-hand man 得力的助手 

ring a bell with sb 使某人回忆起某事 

road hog 驾车乱抢路的人 

rock the boat 破坏别人的计划;使遇到危险 

roll out the red carpet 铺上红色地毯 

rotten to the core 腐烂透顶 

rough hours 读书时的艰苦生活 

rough sb up 对某人粗卤 

round-about way 采用间接的方法 

row in one boat 从事相同事业;相同命运 

royal road 容易取得成功的捷径 

rubber check 空头支票 

rubber stamp 人云亦云的人 

run across 偶然碰见 

run down 撞倒;诋毁;破旧的 

run into 突然碰到某人 

run of the town 轰动一时的人 

run out of sth 用完 

run sb out of the town 把某人逐出市外 

run up against 遇到 

run wild 到处跑 

sad dog 放荡的人;易闯祸的人 

sad news 餐厅的帐单 

sail under false colors 挂羊头卖狗肉;冒充 

salt of the earth(world) 社会中坚 

same old stuff 陈旧货色 

save lots of grief 省掉许多麻烦 

save one's breath 节省口舌 

save the day 反败为胜;挽救了大局 

save up 储蓄 

say it with flowers 笑容可掬,细生细气 

say no more. 别再说了. 

Says you! 你是胡扯! 

scare the devil out of sb 吓得魂不附体 

scratch sb a note 写封信给某人 

screw-ball 有怪僻的人 

search me. 我不知道. 

second sight 超人的预见力 

secret sorrow 难言之隐 

see after 照顾 

see eye to eye 我们意见相同. 

see it through 使某事顺利通过 

see my point 了解;明白 

see off 送行 

see to it 留心、细致地办好某事 

see you around. 再见. 

sell like hot cakes 销售得很快 

sell sb down the river 出卖某人 

send in 提出;交出 

serve sb right 活该 

service station 加油站 

set about 考虑;留意 

set back 拖延 

set forth 说明 

set my heart on 对...倾心 

set the world on fire 震惊天下 

settle down 安定 

seventh heaven 极乐世界 

shake a leg 跳舞;赶快 

shake and make up 言归于好 

Shame on you! 你真丢脸! 

she's a smart dresser. 她是一个注重服饰的人. 

she's been two-timing me. 她背着我和其他男人约会. 

she's got it! 她迷倒了许多人. 

she's not the only fish in the sea. 她并不是世界上唯一的女人. 

shed of 领先 

shedding crocodile tears 猫哭老鼠 

shit of luck 倒霉 

shoe is on the other foot 今日不同往昔 

show off 炫耀 

show sb the ropes 传授秘诀 

show sb the(back) door 下逐客令 

show up 露面;出现;突出 

sick of, be 讨厌 

side money 外快 

side-kick 莫逆之交 

sign up for 报名参加 

sink in the scale 降低 

sitting pretty 过着舒服的生活 

sixes and sevens 乱七八糟 

sixth sense 第六感 

size up 打量 

sleep in this morning 睡个懒觉 

slip one's memory 一时忘记 

slow-poke 行动迟缓的人 

slowly but surely 稳扎稳打 

small potato 小人物 

smoke like a chimney 烟鬼 

smoke o.p.b 吸别人的烟 

snake in the grass 隐藏的危险 

snap out of it 突然改变情绪;振作起来 

snowed. (学生)被一个问题弄糊涂. 

so that's it 原来如此 

So what? 那又怎么样? 

soft-soap 谄媚 

somehow or other 莫名其妙地 

sore spot 伤心事,旧疮疤 

sorry to have kept you waiting. 抱歉,让您久等了. 

sounds just like 看样子就象 

speak of the devil 说曹操曹操到 

speak the same language 志同道合 

spell out sth 讲清楚 

spill the beans 露马脚 

spoil the show 演杂了 

sports bums 吃闲饭的球员 

square deal 公平交易 

stab-in-the-back business 暗箭伤人 

stand a change 有机会嬴 

stand on one's own feet 独立自主 

stand one up 失约而使人白等 

stand one's ground 一步也不退让 

stand sb up 让某人空等一场 

stand up for sth 支持;拥护 

standing ovation 站起来热烈鼓掌 

stay away from 滚开 

stay out o.p.b (other people's business) 不要管别人的闲事 

stay up late 熬夜 

steamed up 怒火中烧 

step on one's toes 触怒某人 

step out 出外约会;暂时离开工作 

sth must be done 非马上采取点行动 

sth tells me 我好象感觉 

stick around 在附近等着 

stick your nose into 让你忙着 

stick-up 抢劫 

stomach's growling 肚子咕噜咕噜地响 

stop by 过来一会 

stop pulling my leg 不要开玩笑了 

storm in a teacup 大惊小怪 

straight from the horse's mouth 据可靠消息 

strike out 删去;想出 

string sb along 常常戏弄某人 

stuffed shirt 自命不凡的讨厌鬼 

sugar daddy 老色狼 

sugar report 情书 

suit one's taste 合某人的胃口 

Sunday dress 最好的衣服 

swelled head 骄傲自大 

switch off 关掉 

swith majors 转系 

take a back seat 处于默默无闻的地位 

take a break 休息一下 

take a good look at 仔细看 

take a hand in 插手某事 

take a look 瞧一瞧 

take a rain check 改天吧. 

take advantage of 欺负;占便宜 

take care of sb later 迟些对付你 

take down 记下 

take for 误认为 

take for granted 想当然 

take French leave 不辞而别 

take in a movie 看一场电影 

take it easy 放松;别紧张 

take it easy. 不要紧张 

take it or leave it. 别讨价还价 

take it out to sb 拿别人出气 

take no for an answer 不许回答“不”字 

take notes in outline form 记大纲式的笔记 

take offense 生气 

take one's hat off to 表示尊敬佩服 

take one's time doing sth 从容不迫;不慌不忙做某事 

take orders from 听命于 

take sb for a ride 绑架某人 

take sth for granted 视为当然 

take sth up 重提某事 

take sth upon oneself 承担一切责任 

take the lead in sth 在某方面领先 

take the load off one's feet 坐下休息 

take the words out of one's mouth 说出心里话 

take things as they come 既来之则安之 

take to 养成喜好;专心于 

take to one's heels 溜之大吉 

take up 开始;继续;吸收 

take your time. 慢慢来. 

take your word for it 相信你的话 

talk big 讲大话 

talk of the town 非常流行的东西 

talk one into 说服 

talk one's head off 说得天花乱坠 

talk sb into sth 说服某人做某事 

talk sb out of sth 说服某人不要做某事 

talk sense 讲得合情合理 

talk through one's hat 说话瞎扯不负责任 

talk through one's neck 说话瞎扯不负责任 

talk through one's nose 骄傲自大 

tall story 难以置信的故事 

teach sb a lesson 教训某人 

team up with sb 和某人分为一组 

tear down 拆毁 

ten bucks 十美元 

That dame! 那个女人! 

that depends. 那要看情况. 

that has a familiar ring. 那话听起来很熟悉. 

that I can't say 这个我不敢肯定 

That is so! 是这样吗? 

that makes two of us. 英雄所见略同 

that settles that 已经安排了,那就算了 

that should be fun. 那一定会好玩. 

that sounds better. 这样说才是. 

that what you say. 这是你说的.(表怀疑) 

that won't answer. 这解决不了问题 

that's a good one. 无稽之谈 

that's a promise i'll hold you to. 是你许下的诺言,我会叫你兑现 

that's a trade secret. 这是生意人的秘密. 

that's great. 好极了 

that's it. 就这样 

that's more like it. 这才象话. 

that's more than i can say. 一言难尽 

that's my... you're making cracks about. 那是我...,请别拿他开玩笑. 

that's nothing. 不要紧;小意思 

that's right down my alley. 那是我最拿手的. 

that's runs my electric bill up. 使电费增加. 

that's something. 真是了不起. 

that's the boy. 好小子(赞美). 

that's the spirit. 真有道理. 

that's the way it is. 事情就是这样的. 

that's the way it with us. 我们就是这样. 

that's the whole damned trouble. 这就是所有的麻烦. 

that's what i came for. 我就是为这个来的. 

that's what i'm here for. 这是我应该做的. 

that's what you think. 只有你自己这么想吧. 

that's your funeral. 此乃阁下之事. 

thaw out 融化 

the big time 了不起的事;梦想 

the crack of down 破晓 

the dead of winter 严冬 

the devil in her eye 她眼神具有魅力 

the die is cast. 一切已成定局. 

the God's truth 说真的 

the hustle and bustle 喧嚣气氛 

the line is busy 通话中;占线 

the price isn't bad. 不贵. 

the whole world knows it. 全世界都知道. 

there goes your phone. 你有电话. 

there is nothing to it. 太容易了 

there you are. 这是你要的. 

there you go again. 你又来这一套了. 

there's nothing i can do. 爱莫能助 

there's nothing wrong with me. 我精神很好. 

they will be very put out. 他们会很生气. 

they're a drag. 那多讨厌,烦死了. 

think nothing of it. 不要放在心上. 

this is a small something for you. 小小礼物,不成敬意 

this is serious. 我是当真的. 

this will be my treat. 这顿饭我请客. 

thorn in one's side. 眼中钉肉中刺 

thousand and one way 许多办法 

three sheets in the wind 酒醉 

threw a party 举行一个宴会 

thrilled with, be 深受感动;非常高兴 

throw cold water on 泼冷水 

throw the bull 胡言乱语 

tie the knot 结婚 

till the cows come home 很久 

times have changed. 时代不同了. 

to a T 恰好地 

to and fro 到处 

to doctor it up with 用...作料拌起来 

to one's face 当面 

to the best of my knowledge 据我所知 

today just isn't my day. 今天运气不佳. 

Tom, Dick and Harry 一般的人;普通的人 

too much for sb 使某人承受不了 

trade in 以旧换新 

treat sb 请客,招待某人 

turn a blind eye 故意视而不见 

turn a girl's head 把她说得太好;使她以为了不起 

turn against sb 与某人做对 

turn down 放低(音量);否决(提案) 

turn in 交还;交出;就寝 

turn one's back on sb 拒绝帮助别人 

turn one's back to sb 不理睬某人 

turn sb loose 放松;放任 

turn tail 逃跑 

turn the tables 扭转局势 

turn turtle (乌龟、汽车)四脚朝天 

twist another around one's little finger 玩弄于股掌之上 

two heads are better than one. 一人计短,二人计长 

under the sun 世界上任何地方 

under the table 台底交易 

under the weather 身体不适 

under warranty, be 在保修期内 

under way (under weight) 事情在进展之中 

up and about 身体复员,可下地走动 

up to 轮到某人 

up to one's ears, be 沉迷;热中 

up to one's neck, be 太忙于做某事 

up to sth, be 对某事称职 

use one's name as a reference 让某人推荐 

very light in weight 很轻 

very much appreciated, be 很感激 

visit John 上厕所 

wage a war on sth 对某事发动一场战争 

walk sb home 陪某人回家 

walkie-talkie 手提对讲机;搬弄是非的人 

walking dictionary 知识渊博的人 

walls have ears. 隔墙有耳 

wash one's dirty linen in public 公开谈论阴私. 

wash out 精疲力竭,脸色苍白 

watch one's step. 谨慎从事 

watch the budget 小心预算 

watch with hard eye 用注视的目光看人 

watch your step. 小心走路. 

we just make it. 我们刚好赶上. 

we rap well together. 我们很合得来. 

we'll in for the night by then. 到晚上那时,我们一定已经回去了. 

we'll see later. 以后再说. 

we're not pressed for time. 我们并不赶时间. 

wear sth inside out 把衣服穿反了 

wee hours 凌晨 

welcome to the party! 现在你总算懂了! 

well in advancce 老早 

Well, I never! 真想不到 

What a mess! 好乱啊! 

What a pleasant surprise! 真想不到的好事 

What a thing to say! 这是什么话! 

What are we waiting for? 我们还在等什么? 

What are you getting at? 你的意思如何? 

What are you going to sell? 你这是什么意思? 

What are you smoking? 你这是什么意思? 

What are you up to do? 你的意思如何? 

What can you do about it? 你有何办法?看你怎样? 

What do you figure? 你的意思如何? 

What do you give? 你有何高见? 

What do you say? 你的意思如何? 

What held you up? 你为什么迟到? 

What to call it? 这叫什么? 

What were you up to? 你干什么去了? 

What's come over you? 你怎么啦? 

What's cooking? 发生了什么事? 

What's going on? 发生了什么事? 

What's it to you? 这和你有什么关系? 

What's on the schedule? 有什么计划? 

What's on your mind? 有什么事吗? 

What's the big idea? 你这是什么意思? 

What's the catch? 你这是什么意思? 

What's the good word? 你有什么好消息? 

what's the matter 到底怎么样 

What's under your cat? 你这是什么意思? 

What's up? 发生了什么事? 

what's up? 什么事? 

What's your pleasure, Treasure? 你喜好什么吃的,富翁(婆)? 

What's your pleasure? 你喜欢什么? 

whatever made you... 你为什么...? 

whatever you say. 随你的便. 

when in Rome do as the Romans do 入乡随俗 

when the doors open 一开场就进入;太准时 

when there is life, there is hope. 活着,就有希望. 

When's the big day? 哪天办喜事? 

Where are you heading? 你上哪去? 

white lie 善意的谎言 

Who are all the characters? 那些人是谁? 

who said so 谁说的? 

Who's calling, please? 请问您是哪位? 

Who's the lucky guy? 谁是新郎? 

Why not tell it to the Horse Marines? 你以为有人会相信你这一套吗? 

wind up 结束,结果 

window shoping 只看不买地逛商场 

wise up 知道 

with a long face 拉长脸 

with flying colors 成功地 

with open arms 热烈欢迎 

within an ace of 几乎;差一点 

without fail 一定 

woman of the world 精通事故的女人 

won't be long 不会太久的 

Wonders never cease! 奇怪的事永远不断发生! 

words fail me 说不出话来 

work a tight schedule 时间很紧迫 

work away 连续工作 

work like a Trojan 工作勤奋 

work out 计划;想出 

Would there be room enough for me? 有没有空位让我坐? 

Would you like to order now? 现在要点菜了吗? 

Wouldn't she be nice to come home to? 和她生活在一起,不是很好吗? 

wouldn't work for me 不适合我 

yes-man 唯唯诺诺的人 

you are a dead duck. 你完了. 

you are a thoughtful person. 你真周到 

you are all wet. 你完全错了. 

you are just being polite. 你真会说话. 

you are killing me. 真是笑死我了. 

you are your father's son. 你长得很象你父亲. 

you ask for it. 你自找苦吃. 

you bet 的确 

You bet! 当然啦 

you can say it again. 我同意你的说法. 

you can set your watch by him. 他总是很准时. 

you can't beat it. 无人匹敌的 

you can't keep a good man down. 好人自有出头之日. 

you don't know half of it. 你知道什么! 

you don't say so. 是真的吗? 

you get me there. 你把我难住了. 

you get no say. 你无权说话. 

you got me there. 你难住我了,这个我不清楚 

you got the picture. 你了解了. 

you have a point there. 你的见解很对. 

you have outstanding 款还没付清 

you know something? 让我告诉你一件事. 

you leave me in the cold. 你太令我扫兴了. 

you let me down. 你太让我失望了. 

you look upset. 你好象情绪不好. 

you look wonderful. 你气色很好. 

you mean to say... 你的意思是说... 

you said a mouthful. 你说得够多的了. 

you said it. 我同意你的说法. 

You see what I mean? 你明白我的意思了吗? 

you should be smart enough. 你应该聪明一点. 

you stay out of this. 不要插手这件事. 

you're all mixed up. 你全搞混了. 

you're confusing your days. 你把日子弄混了. 

you're putting me on. 你在和我开玩笑. 

you're ribbing me. 你开我玩笑. 

you're thoughtful. 你想得真周到. 

you're way ahead of me. 你讲得那么快,我还没听清呢. 

your timing is just right. 你来得正好. 

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>

# 校园英语迷你惯用语
1. what am i gonna do? i'm gonno miss this curfew. 
怎么办!我会赶不上关门(时间的.) 
美国口语常用 I'm gonna (=going to)及 I wanna (=want to) 
的省略形;听起来虽有亲切感,但应避免在正式的场合中使用. 
curfew 是指"关门"之意. "我赶不上(宿舍等的)关门时间"是 
i'm not gonna make (it for) the curfew. 

2. those people hanging out next door are so noisy. 

经常聚集在隔壁的那些人吵闹的很. 

hang out 是"经常聚集", 等于hang around. 
"经常流连的场所(名词)" 拼为 hangout. 
this coffee shop is our favorite hangout. 
(这家咖啡屋是我们最喜欢聚会的地方). 

3. heaven is eating convenience store "hotdogs" in winter. 

冬天吃便利商店的"热狗"真棒 

表示"幸福,快乐,真棒"等情况时也可以用漫画里的Snoopy"史奴比" 
常说的 happiness is..... nothing is better than eating.... 
以及 you can't beat eating....都是表示"吃.......最棒"之意. 
4. shoot. they cut my phone service again. 

呦!他们(电信局)又切断我的电话了. 

也可以说 they cut me off again. 
shoot (=****) 是"狗屎,胡说"之意; 
****一词最好少用,shoot尚可. 
service是指"公共事业". 
the postal service in this country is not so good. 
是(这个国家的邮政事业不太好). 

5. who am i gonna bum some money from next? 

我下一个该向谁借钱呢? 

bum是"敲竹杠,乞讨",含有"有借无还"的意思, 
如: Can I bum a cigarette from/off you? 
(我可以向你要一支香烟吗?). 
也有 Can I hit you up for 1,000 yuan till next month? 
(我可不可以向你借1,000元,下个月还你?)的说法. 

6. this room's starting to smell like a compost heap. 

这个房间开始有些(垃圾)臭味了. 

compost heap 是"肥堆",用作"恶臭"之意. 
"垃圾"一般称为 trash(英国人称为rubbish), 
厨房的"菜屑碎肉之类的垃圾"称作(kitchen) garbage. 
同时,"(不)可燃垃圾"称为(non) burnable waste. 

7. that pervert again?! he gives me the creeps. 

那个色狼又出现了!?他让我浑身其鸡皮疙瘩. 

pervert 是"变态者","调戏孩子者"称为 child molester, 
"偷窥者"称为peeper.(你这老不正经的!)常用 you dirty old man! 
....gives me the creeps 是"....使我起鸡皮疙瘩". 
he's creepy. 是(他令人毛骨悚然)之意. 

9. i kill time. 消磨时间. 

kill除了有"杀死"的意思以外,还有许多不同的意思. 
如: the noise killed the music. 是指(噪音吵的听不到音乐)之意. 

10. i blow-dry my hair. 吹干头发. 

dry 是"弄干"之意. "用毛巾擦干"是 towel oneself, 
"用力擦干"就用 towel away. 

11. 缩写表达方式一览表. 

英美人士在会话中,常使用缩写的词语,以使会话更为生动. 
以下是一些使用频率较高的缩写词句,以供参考. 

when's ---- when is; he's ---- he is/ he has; 
kinda ---- kind of; it's been ---- it has been; 
what're ---- what are; what'll ---- what will; 
that'll ---- that will; I'd ---- I would/ I had; 

It'd (be) ---- It would (be); wanna ---- want to; 
gonna ---- going to; I've gotta ---- I have got to; 
C'mon ---- Come on; shoulda ---- should have; 
'cause ---- because; a lotta ---- a lot of; 

12. i feel relief when i see the questions. 

看完题目后方下心. 

what a relief! 是(多么令人感到欣慰/放心!)的意思. 

13. i rack my brain trying to remember the answer. 

绞尽脑汁想答案. 

rack one's brain 是"绞尽脑汁". 
也顺便记下 on the rack, 意思是"非常痛苦". 

14. i throw in the towel. 我认输了. 

throw in the towel 是"承认败北", 源自拳击比赛时的做法. 
也可以说 i give up. 

15. i hope there're a lot of decent guys in that club. 

我希望那个社团多数是正派的人. 

decent是"得体的,体面的"之意. decent guys 通常是指"正派的人". 
指"容貌英俊的男孩",可以用 good/decent-looking guys. 
目前一般所谓的"三高",指的就是 a tall, high-income, and 
well-educated man "高个子,高收入,高学历." 



16. he says he's sick, but i think he just doesn't wanna join us anymore. 

他说他病了,但我想他只是不愿再加入我们的行列. 

(他以生病为借口) 是 it's an excuse that he's sick. 或 
he's using sickness as an excuse. 
还有 I'm gonna call in sick 是"(向工作单位等)请病假"之意, 
真假的时候都可以说. 

17. no. a ratty-haired bookworm, in this day and age? 

噢!现在都什么时代了,还有这种满头邋遢头发的书呆子? 

ratty-haired 是"邋遢的头发"之意. 
bookworm 如字面所示,是"书虫(书呆子)"的意思. 
"用功念书的古怪家伙"在美国俚语中是 nerd, 
而英国俚语指猛k(啃)书的人则说 swot. 

18. that guy! he took our club's video camera home. 

那个家伙!他把我们社团里的摄像机拿回家了. 

guy 是"家伙,(男)人之意;在美国还用 jerk "讨厌鬼" 
如: what a gerk! 表示"好家伙!"之意. 
you shouldn't help yourself to our club equipment. 
是(你不可将我们的社团公物私用)之意. 

19. i invite people to join our club. 

我邀请人来参加社团. 

invite...over 是"邀请人来家里"之意. invitation 是"请柬". 
请柬上注明 r.s.v.p. (法语 repondez s'il vous plait 的简称)时, 
表示 please reply. (出席与否请复函)之意. 

20. i agree grudgingly. 

我勉强的同意. 

形容词 grudging 是"不情愿的,勉强的"之意. 
grudging praise 是"不情愿说的奉承话". 动词 grudge 是"吝惜"的意思. 

21. i stretch to loosen up. 

我伸展身体. stretch 是"伸展". 

22. what is this? what kind of party organizer is he? 

搞什么嘛? 他算哪种聚会主办人? 

(酒不够喝)说 there's not enough drinks to go around. 
而(点心太差)则说 the appetizers are lousy. 
"主办人"称为 party host/hotess. what kind of...?是"哪一种.."之意. 

23. he can really chug his beer. 

他可以一口气喝掉他的啤酒. 

chug 是 chug-a-lug (表示"咕噜咕噜"的象声词,为俚语,"一口气喝下去"的意思) 
的缩写. (各位,让我们一口气喝干啤酒吧!)是说 everybody, get ready to 
chug your beer!. 

24. the ones who get all quiet and suddenly throw up worry me the most. 

有一种人静静的喝酒中间会突然呕吐出来,我最怕这样了. 

"呕吐"可以用 throw up 或 vomit. 俚语中有 puke (还记得//puke吗?), 
barf,heave,upchuck,toss one's cookies 等说法. 也有 watch out! 
looks like somebody lost his dinner. (注意!好象有人丢掉了他(吃) 
的晚餐)的委婉说法. 

25. i don't think the wimpy drinkers are gonna last long in this club. 

我不认为那些酒量差的老兄会在这社团呆的太久. 

wimpy 是"窝囊(wimp)的"意思, 如: what a wimp! (多窝囊啊!). 
(他不太会喝酒)是 he's a light drinker.; (他酒量普通)是 he's a social 
drinker.; (他是一个善饮者)则说 he's a heavy/hard drinker. 

26. he looks like he can hold his liquor. let's see how long he lasts. 

他看起来好像海量,让我们看看他能撑到几时. 

he can hold his liquor. 是(他喝酒不醉/海量). 而 he can't hold his 
liquor. 则是(他一喝酒就会乱来)之意. liquor 是"酒精饮料". 
在美国,"酒店"称为 liquor store. 而(我可以把你灌醉)是说 i can drink 
you under the table. 

27. laugh while you can, fella. 

看你还能得意到几时!小子. 

fella 是 fellow 的转化, 以为"男子;家伙".说 out-drink...时是"喝赢.." 
的意思. (让我们看看谁最会喝)是 let's see who can outdrink the others. 
或说 let's see who can last the longest. 

28. wow!! i lucked out! we're going back the same way. 

哇!!我幸运透了! 我们可以同路回去. 

luck out 是"幸运透了"之意. he lucked out. he didn't get drafted. 
是(他很幸运免服兵役). (我们住在同一方向/同一条路线)则说 we live 
the same way/one the same line. 

29. i've brought the best-looking girls, and this is the best you could do? 

我邀请了最漂亮的女孩子,而你们只能做到这个程度? 

best-looking 是"最好看的..."之意. this is...?是"只能...吗?". 
"最差的男人"可以用dog (即俚语中"最没魅力的人"来称呼,如: What 
a bunch of dogs!) (**我分特.早知道dog还有这个意思,我一定不会用 
它作昵称的,不过话又说回来了,这个词义你一定记住了.呵呵**) (没什么 
好选的!)可以说 Slim pickings! 

30. don't tell me. is he after her, too? 

不至于吧,他也在追求她?! 

don't tell me (that...) 是口语"不至于吧;别开玩笑"之意. 
be after...是"追着...". the police are after him. 是(他被警察 
追着)的意思,而 what's he after? 则是(他想要追求什么?)之意. 

31. they are in their own world. 

他们沉浸在自己的天地里. 

be in one's own world 是"沉浸在自我的世界"之意. 也可以用在指爱情 
以外的情形. (他们相互恋爱着)可以说 they're completely in love with 
each other., 或是俚语用法的 they're crazy/mad/nuts about each other. 

32. he was more interesting than i expected. 

他比我想像的还风趣. 

i never would have guessed he would be so interesting. 是(我从未想到 
他是如此风趣)之意. 相反的,(我不知道他是这样的一个土包子)则说 i didn't 
know he was such a jerk. 

33. yuck! the guy's wearing a tux. 

呦! 那位仁兄穿起晚礼服来了. 

it's yucky! 是稚语的(糟糕了!)之意. tuxedo 在口语中只说 tux即可. 
而(我不知道要穿正式礼服)是 i didn't know i had to dress up., 或说 
i didn't know this was gonna be a dress-up party. 

34. they're gonna be rolling in it. 

他们会赚死了. 

he's rolling in it/money. 是(他正在大赚其钱)的常用句. 
make a big profit on...也是"大赚..."之意.如: they must have 
made a big profit on this party. 是(他们在这次聚会上,一定大赚一笔). 

35. i round up the gang. 聚了一帮人. 

i drink to a toast. 干杯. 在欧洲,干杯时常说 cheers! 或 mud in the eye! 

i reach for some snacks and munchies. 伸手抓点心吃. 动词munch 是"嘎之 
嘎之的咬/嚼"之意.munchies是名词点心. 

36. i gorge myself on the food. 狼吞虎咽的吃. gorge oneself 是"狼吞虎咽"之意. 

i come on strong and try to pick up a girl. 为亲近那女孩猛灌迷魂汤. 
come on strong 是"侃侃而谈", 
此处含有"猛灌迷魂汤"之意. 
pick up a girl 在此处是指"拍女孩,找个女孩交朋友"之意. 
make a smooth pick up 是"很顺利就交上(女朋友)"的意思. 

i jeer and start yelling. 喝倒彩. 

i do an impersonation. 做模仿表演. 

37. i get dead drunk.醉倒了. 翌日醒来再喝酒,"以酒攻酒" 称为 a hair of the dog. 
古时候人们认为被哪只狂犬咬着,就用它的毛来治疗. 
有这个传说转意而来就有了"以毒攻毒"的意思. 

i take care of someone who has passed out. 照顾一个醉倒的人. 

请注意,passed out 而不是 passed away.呵呵. 

38. i wonder if two crates of cabbage is enough. 

我不知道两箱包心菜够不够. 

crate 是指"(运送,打包用的)箱柜,竹笼"等. cabbage 是"包心菜". 
此处将 two crates of cabbage 当作一个整体,所以动词用单数 is. 
如果说 Shall I go and get another crate, just in case? 是指 
(是要我再去拿一箱,以防万一吗?) 

39. well, since he's making such a fuss, guess i'll just have to. 

好吧!因为他很罗嗦,我想只好就听他的吧! 

since 是"因为",用来表示"理由". 
make a fuss(about .....) 是"小题大作;罗里罗唆"之意. 
just have to (do so) 是"只好听他"之意. 
(哼,她总是独断专行)可以用 gosh, she always has her own way. 
(怕怕的问, is she Angel?? :-P) 

40. hey, there're some cute girls over there. let's go! 

嘿,那边有些漂亮女孩.我们去吧! 

cute girl 是"可爱的女孩".美国俚语也用 chick "妞"或 
babe (=baby) "可人儿"来称呼女孩子. 美国的棒球王 babe ruth 是因他长的 
一副娃娃脸而被大家称为 babe. 

41. these guys think they're really great, don't they? 

这些家伙以为他们真的很了不起,不是吗? 

"自我满足"是 self-satisfaction, 也可以用 complacency. 
(无聊!胡说八道!废话!)等说法可以用 Nonsense! 
(笨得无可救药!)可以说 a fool remains a fool until he dies. 
42. i thought she was just a rich princess, but it looks like we 
have a lot in common. 

我以为她不过是千金小姐,但看来我们有许多共同点. 

带着轻蔑口吻的"千金小姐,阔少爷"常用 spoiled rich kid/brat. 
have a lot in common 是"有许多共同之处". 
we have good chemistry. 是一句俗语,意味(我们很谈的来). 

43. i'm glad i got it off my chest. 

我很高兴自己把心事讲出来. 

got it off my chest 是"把心事吐露出来". (为什么不把心事讲出来? 
你会觉得舒服的多)是 Why don't you get it off your chest? 
You'll feel much better; 相反的,想说(我有心事)可以用 I have 
something on my mind. 

44. she always says, "i don't know what to do...", but she's just 
showing off. 

她总是说"我不知道该怎么办",....但她只是为了要炫耀自己. 

show off...是"炫耀......"之意. "夸耀"可用 brag 或 boast, 如: 
she's always bragging/going on about her boyfriend. 
(她经常夸耀她的男友). 

45. we've been through a lot but we're still together. it must be fate. 

我们历尽沧桑后仍在一起,必定是命中注定的. 

we've been through a lot 是(我们一起历尽沧桑)之意. 
it must be fate. 是说(一定是命中注定的)之意. 
(我想我们是命中注定在一起)可以说 I guess we're meant to be stuck 
with each other. 

46. i guess sometimes people hit it right off. 

我想有时候人们初次见面就会很投缘. 

hit it off (well) 是"很投缘"之意. i hit it off well with him. 
或 he and i hit it off (well) together (with each other). 是指(我和他非常投缘,我们很谈的来)之意. right含有"开始就...."之意. 

47. we talked so long, i ended up missing class. 

我们谈了好久,把课都给误了. 

end/wind up doing... 是"结果....."之意. 
(今天逃课算了!)是用 i'm gonna miss/cut/ckip class today. 
俚语也可以说 i'm gonna play hooky. 

48. since she started college, all of a sudden she's miss glamor. 

她上了大学后,一下子变得很时髦. 

英语的 glamor 含有"妩媚,魅力"之意. (她看起来非常耀眼,)可以说 
she looks too flashy. 或 her outfit is a bit too much. (她的穿着太过分了.) 

49. next to her, anybody would look good. 

谁只要在她的旁边,看上去都长得不错. 

"难看"是 ugly/ugly-looking, 俚语也用 dog, 可用于男女. 
i am not here just to make her look better. 是(我不在这里只是 
为了让她好看些的). 

50. i confide a secret to a friend. 向朋友吐露密秘. 

confide...to..是"向...吐露.."; confide in... 则是"吐露秘密给..."的意思.能够吐露秘密或心事的朋友称为 confidant "密友,心腹". 

i break off a relation. 跟她断交. 

break off 是"分离,离开". patch up 原意为"补缀"之意, 
此处是指"言归于好"的意思. 

51. she's real pretty, but i bet she has a boyfriend. 

她真漂亮,但我打赌她已经有男朋友了. 

此外, she's a beauty/fox. 和 she's so hot/cute. 等也是同样的意思. 
i bet (that)... 是"我相信......" 

52. looks like those two are up to something, huh? 

最近那两人好象怪怪的,关系暧昧. 

和 looks like something's going one there. 相同. 
be up to...是"从事于......,企图于....."之意.如: 
what's she up to? (她想做什么事?). 而 they can come 
in the open. 是(他们可以大大方方的交往)之意. 

53. girls just love hanging out in the bathroom. 

女孩子喜欢在洗手间里磨蹭. 

love doing/to do...是"非常喜欢做....." hang out 是"徘徊". 
而 I was just touching up my make up/powdering my nose 
in the ladies room. 是(我刚在女用化妆室补妆)之意. 

54. i lose my mind just standing next to him. 

和他站在一起就使我意乱情迷. 

lose one's mind 是"失神,忘形"之意. have butterflies in one's 
stomach 是"意乱情迷",如: he gives me butterflies. 
(我不禁微笑)则说 i just can't keep from smiling. 

55. too much! matching outfits! 

太过分了! 情侣装! 

too much! 是(太过分!). matching 是"相配的". 
their clothes matches. 是(他们的衣服相配)之意. 
outfit 是指"(全套)服装". nice outfit! 是(好棒的打扮!). 

56. i'd never try to woo someone with fine cars or gifts. 

我决不会用香车和礼物来求婚. 

woo...是"求爱,求婚"之意. 也可以用 try to win over a girl's heart的说法. fine 是"豪华的". 想开玩笑说(他是我的司机)就说 he's just my chauffer., 或 he's just my wheels/transportation. 

57. he said he wouldn't try anything, but come on.... 

他说他不会做任何事,但说归说... 

i wouldn't come on to you. 是(我不会逼迫你的)之意. 
i wouldn't do anything funny. 是(我不会乱来的). 
此处的 but come one 是接近于"够了,够了",也可用 give me a break. 
含义相似. i can read you like a book. 是(我深知你心)之意. 

58. we are kind of stuck in a rut. 

我们有点陷入固定(乏味)的生活方式. 

rut 是"车痕;常规;惯例". be/get stuck in a rut 是"陷于同一种模式, 
惯例"之意. 与 be/get in the same old routine. 同义. 
(是该分手的时候了)是说 time to call it quits. 

59. i wonder if there's an easy way to break up and still be friends. 

我在想有没有既能分手又能彼此做朋友的简便方法. 

"分手"可说 break up 或split up, 如: she broke up with him. 
(她和他分手了). 想要彻底分手时,可以说 let's not make it messy. 
(我们不要拖泥带水的分手.). 也可以说 let's make a clean break. 
(让我们彻底的分手.) 

60. isn't that something how he left me after four years? 

交往了4年之后,他这样离开我不是太过分了吗? 

isn't that something...? 是"...不是太过分了吗?" 
俗语说 he dumped/dropped me. 是(他甩了我)的意思. 
he turned me down. 则是(他拒绝了我). 

61. i pretend to give him the cold shoulder. 

我故意假装冷落他. 

give someone the cold shoulder 是"冷落某人"之意,此处的 shoulder是由从前对讨厌的客人露出肩膀,表示厌恶引申来的. 
cold turkey 是指"冷漠的人". 

62. i played the field. 和很多异性交往. 
相反的,如果"只和某一特定对象交往"时,则说:go steady. 

i fly into a rage. 很生气 
rage 是"盛怒"之意. fly into raptures 是"兴高采烈". 

i assume a defiant attitude. 采取倨傲的态度. 

63. i suggest we make a clean break. 

我建议我们干干净净的分手吧! 

夫妻或情侣要分手时,也可以用 break up 表示. 

64. being a tutor for slow learners is really a drag. 

身为反映迟钝学生的家庭教师真累人. 

being....是用动名词为主语的句型. tutor 是"家庭教师,(英国)大学的导师". 
slow learner 是"反映迟钝的学生", drag 是"累赘"之意. 反过来说 being a tutor for quick learners is duck soup/a soft job. 是(作为头脑灵敏学生的家庭教师真情松). 

65. that guy has connections in lots of shady jobs. 

那家伙在很多不正经的工作方面都有人际关系. 

此处的connections 是指"关系,门路,社会关系"等义. 
shady 是"可疑的". he has powerful connections in the 
publishing world 是(他在出版界有强而有力的社会关系). 
after all, connections talk. 是(终究还是有门路才行的通). 

66. yeah, working conditions matter, but i want a job where 
there're lots of babes. 

是啊,虽然工作条件很重要,但我想要在有很多侨妞的地方工作. 

yeah 是 yes 的口语说法. yeah....是自言自语的口气, 表示 
"虽然...."之意. working conditions 是"工作条件". 
此处的 matter 做动词用,表示"非常重要"之意. 
67. uh-oh, this looks like an underworld operation. 

哎呀!这地方看起来象是黑道经营的场所. 

this (=this place) 是"这里,此处"的意思. underworld 指黑社会. 
operation 是"事业,经营". i'd better wash my hands of the 
underworld and go straight as soon as possible. 是(我最好尽早改邪归正). 

68. come to think of it, i've been working here for five years. 

想起来,我在这地方已工作五年了. 

come to think of it 的意思是"来想想看".也就是 when/now that 
i come to think of it 的简略. 此句用现在完成进行式 have 
been....ing 表示"持续..". it's about time i left this job 
是(是我该离开这职务的时候了!)之意. 
69. now that i'm out on errands, they'll never know whether i am working or not. 

由于我在外面跑腿,他们永远也不知道我是否在工作. 

now that (=since)...是"由于....."之意. out on errands 是"在外当跑腿". 
he is always going on/running errands for his girlfriend. 
是(他总是替他女朋友跑腿). 

70. gross. that cook doesn't even wash his hands after he goes to the bathroom. 

好可怕哦....那厨师上完洗手间后,连手也不洗. 

gross 是"哎呀!",表示"好可怕"之意. not even..."连...也不...". 
bathroom 是"洗手间",在公共场所也可以称为 lavatory, restroom 
washroom 等. i want to work in a clean, tidy kitchen. 是(我想在一个清洁,干净的厨房工作). 

71. i always wanted to wear this uniform. 

我一直想穿这套制服. 

也可以改用现在完成式,而说 i've always/long wanted to... 
wearing an italian tomato's uniform has been my long-cherished desire. 
是"穿着意大利番茄的(餐厅)制服,是我长久以来的梦想". 

72. this manager's such a lech! 

这个经理真是好色之徒. 

lech 是"好色之徒,色狼". have you suffered sexual harrassment? 时(你有没有 
受到过性骚扰?). huh, i'd like to be seduced by such a handsome manager. 
是(哦,我倒也想要被这样英俊的经理诱拐). 

73. i still have to keep a smile on my face, even to this strange customer? 

对这种怪客人,我还得强颜欢笑吗? 

美国俗话中的 turkey 是指"无聊的家伙",左句也可以改用 even to this turkey. 
my fact got tense from smiling all the time. 是(我总是笑着,把脸都笑僵了.) 

74. i was only a little late. don't have a fit about it. 

我只不过是迟到了一会儿,不要发火嘛! 

a little late 是"稍稍迟到". "...迟到"是 be late for.... 
"及时赶上"是 be in time for... have a fit/forty fits 是"勃然大怒". 
don't be fussy about trifles. 是(不要大惊小怪)之意. 

75. god, i've had it with this job! 

天啊!这种工作我真是受够了. 

have had it 是"吃不消,厌烦了"之意. 和 i've had enough of it! 同义. 
i am done with it. 是(我不干了). you're fired. 是(你被解雇了.) 
(我被解雇了)可以说 i was fired/got it in the neck. 

76. i scrunch up my nose at the sight of (table) scraps in the garbage. 

残羹剩菜使我掩鼻. 

scrunch 压迫,挤压, 捏成一团,揉成一团. 
scraps 是"不可吃的残羹剩饭",而 leftovers 则是"可以再吃的剩菜". 

78. i wonder if there are any alumni of my school at this company. 

不知道这家公司里有没有我们学校的校友. 

alumni 是 alumnus 的复数形式,是指"毕业生,校友". 女子大专的毕业生其复数 
形式为alunma. "同学会"是 alumni association; "同学的聚会,聚餐"则称为 
alumni metting. wonder if...从功能上讲相当于疑问句,所以句中使用any. 

79. i guess the whole world runs on connections. 

我想全世界还是靠人际关系运作的啦. 

run on 是"用...运转/开动",如 this toy runs on batteries. 
(这玩具使用电池开动的). how can i find a job without connections? 
是(没有人际关系我怎么能找到工作呢?) 

80. working for a foreign company'd be glamorous. 

在外商公司工作会很神气. 

"外商"也称为 foreign affiliate. glamorous 是指"(工作等)富有魅力的,迷人的" 
之意;在此处也可以用 stylish "时髦的"加以代替. working for a local govern- 
ment might be good. 是(在地方政府机关工作也并不坏)的意思. 

81. looks like i'm gonna have to buy a winter suit, too. 

看来我也得去买一套冬季西装. 

suit /sju:t/ 是"(上下成套的)西装",而suite /swi:t/ 是饭店的"套房", 
请注意拼写及发音的差异. 如果说 in one's birthday suit 则是指"裸体"的意思. 
82. god, we look like sheep---we're all carrying the same folders. 

天啊!我们都带着同样的文件夹,看起来一模一样. 

sheep 是"绵羊",单复数同,此处指"模仿别人着,盲从者", 
含有轻蔑的意思. they are all sheep, looking just alike. 
是说(他们这群人相互模仿,看起来一模一样). 

83. i'd like to stay away from jobs that are demanding, dirty, or dangerous. 

我想避开劳累,污秽或危险的工作. 

stay away from ...是"离开...". 英语中所谈到的"工作上的三d"是指 
demanding "苛求的;劳累的", dirty "污秽的,肮脏的", dangerous 
"危险的". 相反的, can you imagine an easy, clean and safe job? 
则是(你能想象安逸,干净而安全的工作吗?) 
84. that guy checks out every lead he lays his hands on. 

那老兄只要一得到消息,就去应聘. 

此处的 lead 是"线索". lay one's hands on 则是"抓住,得到,找出"等意. 
does it increase job chances in any way? 是(那样会增加就业的机会吗?)之意. 

85. shoot! i forgot to take off my nail polish. 

糟糕!我忘了擦掉指甲油. 

take off (=remove) 是"除去". nail polish (=manicure)是"指甲油", 
而脚趾则涂 pedicure "脚指甲油".(她那样涂着红指甲油,大概不会被录取的)是说 
she won't be employed, with that red nail polish. 
86. i am a shoo-in for a job at this company. 

我可以轻而易举的取得这家公司的工作. 

shoo-in 是指在选举竞赛时,"轻易可以获胜,为有力的候补"之意. 
i'm at best a dark horse. 是(我最多是一匹黑马而已). 
shoot, some guys can't even be in the running. 则意味(哦.. 
有人连候补都当不成). 

87. it's their treat. might as well get something expensive, since 
i'm not taking this job anyway. 

这是他们(公司)请客,反正我不想在这里工作,不妨叫贵一些的吧! 

此处的 treat 当名词用, 表示"请客"之意. he treated me to a 
steak. 的treat做动词用, 表示(他请我吃牛排). might as well... 
是"不妨.....". take a job 是"就业".而 anyway 是"不管怎样"的意思. 

88. are they really gonna throw their drinks in my face if i renegue? 

如果我回绝的话,他们会不会生气? 

throw...in my face 是"向我丢.....". renegue /ri'ni:g/ 是"食言,背弃(诺言等)" 
Will they sue me for breaches of contract? 是(他们会不会为了我的毁约而 
控告我?)之意. 

89. i put on just a little makeup. 稍微化妆. 
完全没化妆用 wear no makeup 即可. 

i choose a tie that goes with my suit. 选择搭配西装的领带. 
此处的go 用来表示"相配"之意. soy sauce doesn't go well with wine. 
是(酱油和酒是不能调在一起的). 

90. i make a slip and say more than i should. 说溜了嘴而话多. 

make a slip 是"说溜了嘴". 而 a slip of the pen 是"多写了不必写的事情"之意. 

i congratulate my friend who has make it. 向被录取的朋友祝贺. 

congratulations! 是(恭喜). 含有"努力后得到"之意,因此在对新娘祝贺时 
最好不用. 也不用做新年贺词. 

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>

# 洋话连篇
1、I'm not myself 我烦透了 
2、Don't bother me！ 别烦我！ 
3、Give me five more minutes please。 再给我五分钟时间好吗？ 
4、How did you sleep? 你睡的怎么样？ 
5、Don't hog the bathroom! 别占着卫生间了！ 
6、don't hog the shower. 别占着浴室了！ 
7、don't hog my girlfriend. 别缠着我的女朋友了！ 
8、Get outta there! 快出来！ 
9、I will treat you 。 我请客。 
10、What are you in the mood for? 你想吃什么？ 
11、Whois gonna drive? 谁来开车？ 
    Who's driving? 
12、You know what I mean? 你明白我的意思吗？ 
13、Could you run that by me again? 你能再说一遍吗？ 
14、so what you are trying to say is... 那么，你想说的是... 
15、Whadja do last night? 昨晚你干嘛去了？ 
    Whadja=What did you 
16、Didja have a good time? 玩的开心吗？ 
    didja=did you 
17、Where wouldja like to go tonight? 今晚你想上哪儿？ 
    Wouldja=Would you 
18、i am running late. 我要迟到了。 
19、i've gotta get outta here. 我得离开这儿了。 
20、i've gotta catch the bus. 我要去赶公共汽车了。 
21、gotta=got to 
    wanna=want to 
    gonna=going to 
22、Yo__taxi! 嗨，出租车！ 
23、Where to ? （你）要去哪儿？ 
24、i want to go to... 我要到...地方去。 
25、What do I owe you ? 我该付你多少钱？ 
26、let me out here. 让我在这儿下车。 
27、HI! What's up, buddy? 嗨！ 还好吗？，伙计？ 
28、What'cha been doing? 这些日子在干什么呢？ 
    What'cha=What have you 
29、How ya' been? 这些日子过的怎么样？ 
    HOw ya' been=How have you been? 
30、i'm fine. 我很好。 
31、Do I have any messages? 有人给我留言吗？ 
32、What's on the schedule for today? 今天有那些日程安排？ 
33、Has the boss come in yet? 老板来了吗？ 
34、Hello! This is Hogan,is William in? 
    你好！ 我是Hogan,请问William 在吗？ 
35、may i take your message? he is not in. 
    他现在不在。我可以为你留言吗？ 
36、i'm really busy. can i call you back later? 
    我现在真的很忙，我晚点给你打过去，行吗？ 
37、Thank you for your time,goodbye! 
    占用您的时间了，谢谢您。再见！ 
38、Are you doing anything tonight/this weekend/tomorrow? 
    你今晚/周末/明天有空吗？ 
39、If you are not busy tonight, would you like to go out with me? 
    如果你今晚有空的话，愿不愿意和我一起出去？ 
40、mayby we can get together sometime. 
    也许今后我们有机会在一起。 
41、you look beautiful tonight. 
    今晚你看上去真美啊！ 
42、i've really had a good time tonight. 
今晚我过的很开心。 
43、i'd like to see you again sometime. 
希望能再见到你。 
44、How was your day? 
今天过的怎么样？ 
45、HOw are things at work? 
今天工作进行的怎么样了？ 
46、How are things at the office? 
今天在公司怎么样？ 
47、How are thing at school? 今天在学校（过的）怎么样？ 
48、you'll never believe what happened to me today at shool/work. 
你永远也猜不到今天我在学校/工作中遇上了什么事！！ 
49、YOu look great! Have you been working out? 
你气色真好，你经常锻炼吗？ 
50、i need to get back in shape. 
我要减回到原来的身材。 
51、What do you do for exercise? 
你经常做写什么运动呀？ 
52、You are something else! 
你真是出类拔萃！ 
53、You are out of sight! 
你真优秀！ 
54、You rule! 你太牛了！ 
55、i've got to cram for a test tomorrow. 
为了明天的考试，我得背多少东西呀！ 
56、Hey,How did your English test go? 
嗨，你英语考的怎么样？
57、Wow! Holy cow! That's great! 
哇噻！太好了！真棒！ 
58、oh! No! That's terrible! 噢，太糟糕了！ 
59、What the heck is that? 究竟是怎么一回事？ 
60、Hey,what the heck is going on? 
嗨，究竟发生了什么事？ 
61、Darn it all! Gush! Darn it! 该死的! 
62、get to the point. 言归正传。 
63、as a matter of fact 事实上 
64、to get cold feet 吓的毛发直竖。 
65、to give someone the cold shoulder 冷落某人 
66、How did you say this word? 这个单词该怎么发音 
67、i don't understand. 我不知道。 
68、What's for breakfast? 早餐有些什么？ 
69、What do you want to have for breakfast? 
你早餐想吃什么？ 
70、Would you like some coffee,juice or milk? 
你想喝咖啡、果汁或者牛奶？ 
71、step into my office 到我办公室来！ 
72、Can I see you in my office? 到我办公室来一下好吗？ 
73、Can I talk with you for a little while? 我能和您谈谈吗？ 
74、I am a little a bit busy right now,can we talk later? 
我现在比较忙，可不可以待会儿再谈？ 
75、Sure,no problem,right away! 没问题，马上就来！ 
76、What is it you wanted to talk to me about? 你想和我谈什么？ 
77、What is it? 你向谈什么？ 
78、thank you very much for your time. 多谢您能抽空和我谈话。 
79、Can you give me a hand? 能帮帮我吗？ 
80、sure,no porblem. 当然，没问题。 
81、now's a bad time. can we do it later? 
现在不太方便，能不能等一会儿？ 
82、thanks for the hand. 谢谢您帮忙！ 
83、Can I buy you a drink? 我能请您喝一杯吗？ 
84、this one's on me . 我请客。 
85、I'll drink to that! 我同意！ 
86、Would you like another round? 想再喝一圈吗？ 
87、i've had a hard day. 我今天过的真糟糕。 
88、i'm fed up with... 我实在难以忍受... 
89、i'm sick and tired of ... 我受不了... 
90、i've had it up to here with... 我真受不了... 
91、i really wish... 我多么希望... 
92、Catch you later,buddy! 再见，老兄！ 
93、Take care! 保重！ 
94、See ya' later!/See ya'!/Later! 再见！ 
95、再见的几种用法(在美国很流行哦) 
Adios! 西班牙语 Ciao! 意大利语 Au revoir! 法语 
96、i didn't sleep a wink. 我简直没合过眼。 
97、i slept like a log. 我睡的真沉！ 
98、my job is a nightmare. 我的工作（不好）真是噩梦啊！ 
99、Is your friend available? 你的朋友有男朋友吗？ 
100、oh! she is already taken. 哦！她已经有男朋友了。 
101、Do you think she is my type ? 你觉得她合适我吗？ 
102、i'm gonna go for it. 我要去追！ 
103、she is available. 她没男朋友。 
104、sorry,i'm all tied up right now. 对不起，我现在很忙。 
105、all right.maybe some other time. 好吧，那就下次吧。 
106、i'm sorry,i've already got plans. 对不起，我已经和别人约好了。 
107、that'll be the day. 不可能。（说的是反话）（语气上扬，若是肯定则语气下降） 
108、don't bet on it. 不可能。 
109、oh that's a great idea. 哦，你这主意真够傻的。（语气上扬） 
110、now that was a great meal. 这顿饭真够丰盛！ 
111、Are you up for some dessert? 你要不要来点甜食？ 
112、i couldn't eat another bite. 我实在吃不下了。 
113、the toilet is backed up. 厕所堵上了。 
114、the bulb is burnt out. 灯泡烧坏了。 
115、to blow a fuse. 保险丝烧断了。 
116、you look sick. how are you feeling? 你看起来不太舒服，你感觉怎么样？ 
117、i'm as sick as a dog. 我病的很重。 
118、i'm a little under the weather. 我有点不舒服。 
119、i hope you get better soon. 我希望你很快好起来。
120、I've been studing/working my tail off! 我学习/工作太紧张了！

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>

# 至理名言
no matter how old you get, hug and kiss your mother whenever you greet her. 
不管你有多大，向母亲致意的最好方法就是，投入她的怀抱，亲吻她的脸颊。 


temper, if ungoverned, governs the whole man. 
放纵性情，失去自我。 


the best remedy for a short temper is a long walk. 
慢行降急火。 


trust is the single most important factor in both personal and professional relationships. 
为人做事，信任至上。 


if someone says something unkind about you, you must live so that no one will believe it. 
照样生活，谣言自破。 


when you make your mark in the world, watch out for the envious with erasers. 
当你致力于成功时，小心嫉妒者的破坏。 


things that are what they seem to be, are so rare that you cannot recognize them when you see them. 
事情往往不象你看到的那么简单易认。 


be open and accessible. the next person you meet could become your best friend. 
开放自我而易于接近，下一个见到的人可能成为你最好的朋友。 


the man who never has enough time to do a job properly always has enough time to do it over again. 
工作没做完，总得从头来。 


there's no use going back for a lost opportunity - someone else has already found it. 
机会错过不再有，有人已捡走。 


a man will always remember his enemies, but he will sometimes forget his friends. 
人不要牢记敌人，忘记朋友。 


refuse to share personal and financial information unless you feel it is absolutely essential. 
除非最基本的，不要告诉他人有关你自己的个人和财经信息。 


when you find something you really want, don't let a few dollars keep you from getting it. 
如果发现真爱，别让不太多的钱成为阻碍。 


in prosperity, prepare for change; in adversity, hope for one. 
顺境中虑及变故，逆境中有信心克服。 


you may be fortunate and make a lot of money. but be sure your work involves something that enriches your spirit as well as your bank account. 
你可能很幸运而赚了好多钱，但应确保你的工作给你带来了同样多的精神享受。 


the greatest achievements are those that benefit others. 
最伟大的成就是那些有益于他人的。 


let your children see you do things for your wife, that lets them know how much you love and treasure her. 
让孩子们看到你为妻子效劳，让他们感觉到你对妻子的爱和珍惜。 


make a habit of reading something inspiring and cheerful just before going to sleep. 
睡前读点令人鼓舞和愉快的。 


the secret of happiness is learning to accept the impossible, do without the indispensable, and bear the intolerable. 
承认你曾认为不可能发生的事实，去做而不需要别人认为不可缺少的条件，忍受那些被视为无法忍受的变故，这就是快乐的秘诀。 


all the art of living lies in a fine mingling of letting go and holding on. 
生活的艺术在于对坚持与放弃的合理调配。 


success is a ladder that cannot be climbed with your hands in your pockets. 
成功是得靠你自己双手攀登的阶梯。 


people tend to rise to accomplishments they thought were beyond them if you show them by your confidence that they can do it. 
如果你充满信心地引导，他们能取得超出他们想象的成功。 


it isn't always best to be in a rush. for while it is true that the early bird gets the worm, it's also a fact that the second mouse gets the cheese. 
不用总赶急，早起的鸟有虫吃不假，第二支老鼠吃到奶酪也真。 


you never get a second chance to make a good first impression. 
得到好的第一印象的机会就一次。 


let your handshake be as binding as a signed contract. 
与人握手时，给人信任感。 


change worry time into planning time. 
不要无谓忧虑，去做进一步打算。 


nostalgia is a file that removes the rough edges from the good old days. 
怀旧之情能使美好的旧时光更美好。 


if you stay focused on yourself, you are going to be miserable. 
只关心自己会使你变得可怜。 


the two hardest things to handle in life are failure and success. 
人生最难处理的两件事，就是成功和失败。 


you shouldn't look back except to learn. 
除了知新，还应温故。 


there are two very difficult things in the world. one is to make a name for oneself and the other is to keep it. 
世界上有两件事情很不一样，扬名立万和保持声誉。 


the reason ideas die quickly in some people's heads is that they can't stand solitary confinement. 
有的人信念丧失，只因为孤独环绕。 


what the world needs is an amplifier for the still, small voice. 
应让世上更多的人听到那平静而微弱的声音。 


happiness is not the absence of conflict, but the ability to cope with it. 
快乐不意味着没有分歧，而是有能力解决分歧。 


may your dreams never disappear with age, but may they continue as alive 

and as beautiful as you with the knowledge that they will someday come true. 
愿梦想不因岁月而流逝！愿她永远那么生动、永远那么美丽！因为你知道有美梦成真的一天。 

<div align="right">
    <b><a href="#目录">↥ Back To Top</a></b>
</div>




